﻿ $Folder="\\VDIAASLABSRV101\\AnsibleOutput\"+$args[0]+"\"+$args[1]+"\buildVM\"
 
 $filefound=dir -Path $Folder -Filter *.png -Recurse | %{$_.FullName}
 Write-Host("Validating if the Appv was created : $filefound")
  $status='Red'
 if($filefound -ne '') 
  { $status='Green' }   
    
$outputjson="D:\Appv\cleanimages\output.json"
$outputtemplate="D:\Appv\cleanimages\ouputTemplate.json"

$Folder=$Folder.Replace("\","\\")
Copy-Item  -Path $outputtemplate -Destination $outputjson -Recurse -force
((Get-Content -path $outputjson -Raw) -replace 'APPV','VM') | Set-Content -Path $outputjson
((Get-Content -path $outputjson -Raw) -replace 'Status',$status) | Set-Content -Path $outputjson
 ((Get-Content -path $outputjson -Raw) -replace 'val',$Folder) | Set-Content -Path $outputjson