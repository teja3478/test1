param(
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msi,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msixpackaging_TargetDirectory,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$guid,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msixpackaging_outputdirectory,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$fldrDate2
    
)

#[System.IO.FileInfo]$Path = "C:\project\tortoisesvn.msi"
#variableupdate
#$msi = "\\\\VDIaaSLabSrv101\\msifiles\\notepadexe.exe"
$msiname = $msi.split('\\')
$filename = $msiname[-1]
$msiname = $msiname[-1].split('.')

$msixpackaging_TargetDirectory = "C:\\MSIXPACKAGED\\input\\"
$sampletemplate = $msixpackaging_TargetDirectory + "sampletemplate-exe.xml"
$msipath = $msixpackaging_TargetDirectory + $filename

#$guid="9c6fcccd9bfe436fa1e9d1bbcf419b62"
#$msixpackaging_outputdirectory = "\\\\VDIAASLABSRV101\\logs"
#$fldrDate2 = "20020284"
#$msixpackaging_signtool = "C:\\Program Files (x86)\\Windows Kits\\10\\bin\\10.0.18362.0\\x64\\signtool.exe"
#$msixpackaging_pfxcert = "C:\\Users\\ansible\\Desktop\\testsign1.pfx"
#$msixpackaging_controlleroutputDirectory= "C:\\MSIXPACKAGED\\output\\"
$msixpackaging_controlleroutputDirectory = $msixpackaging_TargetDirectory.replace("input","output")
#$msipath = [System.IO.FileInfo]$msipath

#for exe under product version last number should be zero 0
#$ProductVersion1=(get-item -Path $msipath).versioninfo.FileVersion
#$j = $ProductVersion1.Substring(0, $ProductVersion1.LastIndexOf('.'))
#$k = $j.Substring(0, $j.LastIndexOf('.'))
$ProductVersion = "1.2.3.0" 
$ProductName=(get-item -Path $msipath).versioninfo.productname
if($ProductName.Length -gt 0){
$ProductName = $ProductName}
else{
$ProductName = "Microsoft"
}

$Manufacturer =(get-item -Path $msipath).versioninfo.companyname
if($Manufacturer.Length -gt 0){
$Manufacturer = $Manufacturer }
else{
$Manufacturer = "Microsoft"
}

$ProductVersion=[string]$ProductVersion
$ProductName = [string]$ProductName
$Manufacturer = [string]$Manufacturer



#templateupdate
$xml = [xml](Get-Content $sampletemplate)
$Path1 = [string]$msipath
$msipath = $Path1.split('\\')
$msiname = $msipath[-1].split('.')
#$xml.MsixPackagingToolTemplate.SaveLocation.PackagePath = $msixpackaging_controlleroutputDirectory+"\\"+$msiname[0]+"\\"+$msiname[0]+".msix"
$xml.MsixPackagingToolTemplate.SaveLocation.PackagePath = $msixpackaging_controlleroutputDirectory+"\\"+"package.msix"
$xml.MsixPackagingToolTemplate.SaveLocation.TemplatePath= $msixpackaging_controlleroutputDirectory+"\\"+$msiname[0]+"\\"+$msiname[0]+".xml"
$xml.MsixPackagingToolTemplate.Installer.Path = $Path1
#$xml.MsixPackagingToolTemplate.Installer.Arguments = $Arguments
$xml.MsixPackagingToolTemplate.Installer.Arguments = "/SILENT /S /qn /ALLUsers"
$xml.MsixPackagingToolTemplate.Installer.InstallLocation = "C:\Program Files\"+$msiname[0]
$xml.MsixPackagingToolTemplate.PackageInformation.PackageName = $msiname[0]
$xml.MsixPackagingToolTemplate.PackageInformation.PackageDisplayName=$ProductName.Trim()
$xml.MsixPackagingToolTemplate.PackageInformation.PublisherDisplayName=$Manufacturer.Trim()
$versionlength = $ProductVersion.split('.')
if($versionlength.Length -gt 3){
$xml.MsixPackagingToolTemplate.PackageInformation.Version=$ProductVersion.Trim()}
else{
$xml.MsixPackagingToolTemplate.PackageInformation.Version=$ProductVersion.Trim()+'.0'
}


$xml.MsixPackagingToolTemplate.PackageInformation.PackageDescription=$ProductName.Trim()
#$outputxml = "C:\"+$msiname[0]+'.xml'
$outputxml = 'C:\package.xml'
$xml.save($outputxml)

write-host($outputxml)
$outputmsix = $msixpackaging_controlleroutputDirectory+$msiname[0]+"\"+$msiname[0]+".msix"
write-host($outputmsix)
$outputmsix1 = $msixpackaging_controlleroutputDirectory+$msiname[0]
write-host($outputmsix1)
$outputmsix2 = $msiname[0]+".msix"
write-host($outputmsix2)
Write-Host($msixpackaging_outputdirectory+"\"+$fldrDate2+"\"+$guid+"\"+"msixpackaging\"+$msiname[0]+".msix")
Write-Host($msixpackaging_controlleroutputDirectory+"package.msix")
#splitting GUID with _
$newguid = "$guid"
$newguid1 = $newguid.split("_")
#Write-Output $newguid1
Write-Host($msixpackaging_outputdirectory+"\"+$fldrDate2+"\"+$newguid1[0]+"\"+"msixpackaging\"+$msiname[0]+".msix")
