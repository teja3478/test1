﻿Set-Content C:\PostInstallationpackages\postinstall_ps.txt 'Post installation step completed'
