Param(

    [Parameter(Mandatory=$True)]
    $package
)



 Add-AppxPackage -Path C:\packages\$package.msix

