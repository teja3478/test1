argValue = "PIPE1"
argAppType = "MSIX"
pipeline {
    agent any
		
    stages {
        stage('PACKAGE VALIDATION') {
           steps {
				build job: 'PACKAGEVALIDATION', 
                                      parameters: [[$class: 'StringParameterValue', name: 'pApplicationTypeName', value: argAppType],
				                   [$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }
        stage('MSIX Automation') {
            steps {
				build job: 'MSIXAutomation', parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }
        stage('LAUNCH TEST MSIX') {
            steps {
				build job: 'PUBLISHINGMSIX', parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }         
    }
}