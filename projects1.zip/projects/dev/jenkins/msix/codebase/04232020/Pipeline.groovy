argPipeName = "PIPE1"
argAppType = "MSIX"
argConfigFile = "/etc/ansible/projects/dev/jenkins/msix/config/jenkins_config.json"
argStageName = ""

pipeline {
    agent any
		
    stages {
        stage('PACKAGE VALIDATION') {
           steps {
				build job: 'MSIX_PACKAGEVALIDATION', 
                parameters: [[$class: 'StringParameterValue', name: 'pApplicationTypeName', value: argAppType],
				             [$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile]]
				script {
				    argStageName = "PACKAGEVALIDATION"
				}
            }
        }
        stage('MSIX PACKAGING') {
            steps {
				build job: 'MSIX_PACKAGING', 
                parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile],
							 [$class: 'StringParameterValue', name: 'pLastExecutedStep', value: argStageName]]	
				script {
				    argStageName = "MSIXPACKAGING"
				}							 
            }
        }
        stage('LAUNCH TEST') {
            steps {
				build job: 'MSIX_PUBLISHING', 
                parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile],
							 [$class: 'StringParameterValue', name: 'pLastExecutedStep', value: argStageName]]	
				script {
				    argStageName = "LAUNCHING"
				}							 							 
            }
        }         
    }
}