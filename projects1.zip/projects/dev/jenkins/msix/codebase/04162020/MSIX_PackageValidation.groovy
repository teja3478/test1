//MSIX Validate MSI - CODE
import jenkins.model.Jenkins
import hudson.model.FreeStyleProject
import hudson.tasks.*
import hudson.*
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import hudson.FilePath
import hudson.model.ParametersAction
import hudson.model.ParameterValue
import hudson.model.StringParameterValue
import jenkins.*
import jenkins.model.*
import groovy.io.*
import static java.util.UUID.randomUUID
import groovy.time.TimeCategory
import groovy.time.TimeDuration


//SIVA  Start

//Build Details
def currentBuild = Thread.currentThread().executable

if (GetStringValue(pConfigurationFile).length() == 0) {
   println "Jenkins Configuration Issue"
   currentBuild.result = hudson.model.Result.FAILURE
   return  
}

def jenkinsConfigFile
String jenkinsErrorCode = ''

(jenkinsConfigFile,jenkinsErrorCode) = GetJenkinsConfigFiles(pConfigurationFile)

if (GetStringValue(jenkinsErrorCode).length() > 0) {
   println "Jenkins Configuration Issue"
   currentBuild.result = hudson.model.Result.FAILURE
   return  
}

String configurationFileName = jenkinsConfigFile.FileName
String configurationFilePath = CheckLinuxFilePath(jenkinsConfigFile.FilePath)
String configFileFullyQualifiedName = configurationFilePath + configurationFileName
 
//JSON Variables declaration
def slurper = new JsonSlurper()


if (GetStringValue(pPipeName).length() == 0) {
   println "Pipe name should not be empty in pipe configuration"
   currentBuild.result = hudson.model.Result.FAILURE
   return  
}

pPipeName = pPipeName.toUpperCase()

if (GetStringValue(pApplicationTypeName).length() > 0) {
   pApplicationTypeName = pApplicationTypeName.toUpperCase()
} else {
   pApplicationTypeName = ''
}

OverwriteBuildNumber(currentBuild, pPipeName, pApplicationTypeName)

//Global Variable
ansibleValutPath = " --vault-password-file"
ansiblePlaybook = "ansible-playbook"
String error = ''
def settingsData
(settingsData, error) = ReadOutputFile(configurationFilePath,configurationFileName)
globalSettingsData = settingsData

def pipeconfigFileInfo = GetPipeConfigDetails(pPipeName)

if (pipeconfigFileInfo == null) {
   println "Pipe confiugration setting invalid. Please verify ${pPipeName} in configuration file"
   currentBuild.result = hudson.model.Result.FAILURE
   return 
}

if (pipeconfigFileInfo.PipeConfigPath.length() == 0 || pipeconfigFileInfo.PipeConfigName.length() == 0) {
   println "Either Pipe name is not valid or Pipe path empty. Please verify ${pPipeName} in configuration file"
   currentBuild.result = hudson.model.Result.FAILURE
   return 
}

String fileOperationFilePath = CheckLinuxFilePath(pipeconfigFileInfo.PipeConfigPath)
String fileOperationFileName = pipeconfigFileInfo.PipeConfigName  
String fileOperationFullyQualifiedName = fileOperationFilePath + fileOperationFileName

(settingsData, error) = ReadOutputFile(fileOperationFilePath,fileOperationFileName)  
pipeConfigData = settingsData   
constSUCCESS = "SUCCESS"
constFAILURE = "FAILURE"
constAppAnalysis = "APPDNA"
constSequencing = "SEQUENCING"
constRemediation = "REMEDIATION"
constLauching = "LAUNCHING"
constPipeName1 = "PIPE1"
constPipeName2 = "PIPE2"
constPipeName3 = "PIPE3"

def csvSettingsData = GetCSVConfigurationDetails()

if (csvSettingsData == null || GetStringValue(csvSettingsData.ErrorCode).length() > 0) {
   currentBuild.result = hudson.model.Result.FAILURE
   return
}

csvColumnSeperator = csvSettingsData.CSVDelimiter
csvArraySeperator = csvSettingsData.CSVArrayElementDelimiter
noofCSVColumns = csvSettingsData.NoOfCSVColumns 

//SIVA  Start
if (GetStringValue(pipeConfigData.PipeName) == null || GetStringValue(pipeConfigData.PipeName).length() == 0) {
   println "Pipe name shouldn't be empty in ${fileOperationFileName} file"
   currentBuild.result = hudson.model.Result.FAILURE
   return
}

/*if (pPipeName.toUpperCase() != GetStringValue(pipeConfigData.PipeName).toUpperCase()) {
   println "Pipe name mismatch either ${fileOperationFileName} file or P"
   currentBuild.result = hudson.model.Result.FAILURE
   return
}*/
//SIVA  End 

constOutputJSONFileName = pipeConfigData.Output.PreInstallOutputFileName 
constOutputFilePath = pipeConfigData.Output.PreInstallOutputFilePath 

workspacePath = CheckLinuxFilePath(pipeConfigData.Input.CSVFilePath)

constReadJsonFileName = ''
constReadJsonFilePath = ''

println workspacePath
 
String csvErrorCode = ''
String jsnErrorCode = ''
def data
def installJsonData
def fileUpdates

(fileUpdates,csvErrorCode) = ReadCSV()
if (GetStringValue(csvErrorCode) != '' || fileUpdates == null || fileUpdates.size() == 0) {
   println "CSV FILE_NOT_FOUND"
   currentBuild.result = hudson.model.Result.FAILURE   
   return 
}

data = fileUpdates
PreparingExecuteAnalysis(data)
//Main finished

/* ================================Common Functions (Start)===============================*/

def GetDateFormat(String format) {
   Date dt = new Date()
   String datePattern = "MMddYYYY_HHmmssSSS"
   
   if (format == "DATE") {
      datePattern = "MMddYYYY"
   } else if (format == "TIME") {
      datePattern = "HHmmss"
   } else if (format == "DATETIME") {
      datePattern = "MMddYYYY_HHmmss"
   } else if (format == "DATETIMEWITHMILLISEC") {
      datePattern = "MMddYYYY_HHmmssSSS"
   } else {
     datePattern = "MMddYYYY"
   }
   
   String dtFormat = dt.format(datePattern)
   return dtFormat   
}

def OverwriteBuildNumber(def build, String pipeName, String applicationType) {
    String buildNumber = build.properties.environment.BUILD_NUMBER.toString()	
	if (GetStringValue(applicationType).length() > 0) {
	   build.displayName = "${applicationType}_${pipeName}_${GetDateFormat("DATE")}_(${buildNumber})"
	} else {
       build.displayName = "${pipeName}_${GetDateFormat("DATE")}_(${buildNumber})"
	}
}


//GetWindowsFilePath method used to get only file path from windows based qulaified full path
def GetWindowsFilePath(String pkgName) {
    return "${pkgName.take(pkgName.lastIndexOf('\\')+1)}"
}

//GetWindowsFileName method used to get only file name from windows based qulaified full path
def GetWindowsFileName(String pkgName) {
    return "${pkgName.substring(pkgName.take(pkgName.lastIndexOf('\\')+1).length(),pkgName.length())}"
}

//GetFilePath method used to get only file path from Linux based qulaified full path
def GetLinuxFilePath(String pkgName) {
    return "${pkgName.take(pkgName.lastIndexOf('/')+1)}"
}

//GetFileName method used to get only file name from Linux based qulaified full path
def GetLinuxFileName(String pkgName) {
    return "${pkgName.substring(pkgName.take(pkgName.lastIndexOf('/')+1).length(),pkgName.length())}"
}


def GetJenkinsConfigFiles(String configInputFile) {
    def jenkinsInputFile
	String fileName = ''
	String filePath = ''
    String errorCode = ''	
	
	fileName = GetLinuxFileName(configInputFile)
	filePath = GetLinuxFilePath(configInputFile)
	
    jenkinsInputFile = [
	    FileName:fileName,
		FilePath:filePath
	]	
	
	if (GetStringValue(fileName).length() == 0) {
	   errorCode = "JENKINS_CONFIG_FILE_NAME_MISSING"
	   println errorCode
	}
	
	if (GetStringValue(filePath).length() == 0) {
	   errorCode = "JENKINS_CONFIG_FILE_PATH_MISSING"
	   println errorCode	
	}	
    
	return [jenkinsInputFile,errorCode]	
        
}


//GetOutput method used to read outout and return RAG status
def GetOutput(String guid) {
 
    String status = ""
    String appName = ""
    String outputPath = ""
    String filePath = ""
    String filename = guid
    String errorCode = ""
    String moduleFilePathAndName = ""
    String emailFilePathAndName = ""
    String enableAnsibleLog = ""
    String outputJsonFileLocation = ""
    String vault = ""
    String errCode = ""
    def data
    def ansibleConfigDetail
    
       (ansibleConfigDetail, errCode) = GetConfigurationDetails ()  


        moduleFilePathAndName = ansibleConfigDetail.ModuleYMLFilePathAndName
        outputJsonFileLocation = ansibleConfigDetail.OutputJsonFileLocation
        emailFilePathAndName = ansibleConfigDetail.EmailYMLFilePathAndName
        enableAnsibleLog = ansibleConfigDetail.EnableAnsibleLog
        vault = ansibleConfigDetail.Vault
        
        
        filePath = outputJsonFileLocation
		
	    //filename = "dummyoutput"   //only for testing purpose - comment it for prod
	    //filePath = CheckLinuxFilePath("/etc/ansible/archive/backup/project/jenkins/testoutputpath/")  //only for testing purpose - comment it for prod		
		String fileErrorCode = ''
        (data,fileErrorCode) = ReadOutputFile(filePath,filename)
        if (GetStringValue(fileErrorCode).length() > 0 ||  fileErrorCode == "FILE_NOT_FOUND" || fileErrorCode == "NO_DATA" || fileErrorCode == "JSON_PARSING_ERROR") {
           errorCode = fileErrorCode
		   println errorCode		   
        } else {           
           status = GetStringValue(data["Overall Rag"].toUpperCase())
           appName = GetStringValue(data.AppName)
           outputPath = GetStringValue(data.Path)
		   errorCode = ''
        }
    
    def result = [
	    Status:status,
		AppName:appName,
		OutputPath:outputPath
	]
    
	return [result,errorCode]
    //return [ status, appName, outputPath, errorCode ]
}


//ReadOutputFile method used to read only json file and return json data
def ReadOutputFile(String outputFilepath, String outputFileName) {
 
    def outputData
    //def currentBuild = Thread.currentThread().executable
    String qualifiedFilePathAndName = ""
	String errorCode = ''
    if (outputFilepath.reverse().take(1).reverse() != "/") {
       outputFilepath = outputFilepath + "/"
    }
   
    if (outputFileName !=  null && outputFileName.length() > 0 && !outputFileName.contains(".json")) {
       outputFileName = outputFileName + ".json"
    }
 
    qualifiedFilePathAndName = outputFilepath + outputFileName
 
    File readOutputFile = new File(qualifiedFilePathAndName)
			
    if (!readOutputFile.exists() || !readOutputFile.canRead()) {
       println "Either ${outputFileName} file is not vaild or not available in the specified location"       
       println "FILE_NOT_FOUND"
	   errorCode = "FILE_NOT_FOUND"
	   return [outputData, errorCode]
    }
	
	if (readOutputFile.length() == 0) {
       println "${outputFileName} file has created without data"   
	   errorCode = "NO_DATA"	   
       println errorCode
	   return [outputData, errorCode]	
	}	
	
    println " "
	if (!outputFileName.contains("config")) {	
        println "Reading output file..."
	}
    def outputText = readOutputFile.getText()
 
    if (outputText == null) {
       println "${outputFileName} file is generated with no data"
       //currentBuild.result = hudson.model.Result.FAILURE
       println "NO_DATA"
	   errorCode = "NO_DATA"	   
       return [outputData, errorCode]
    }
 
    if (!outputFileName.contains("config.json")) {
        println "Output Data ${outputText}"
    }
    //def outputData

    try {
        outputData = new JsonSlurper().parseText(outputText)
    } 
    catch (ignored) {
        println "The following ${outputFileName} file cannot be read by Json engine. It may be empty file."
        println "JSON_PARSING_ERROR"
		errorCode "JSON_PARSING_ERROR"
		//return [outputData, errorCode]
    }
 
    if (outputData == null) {
       println "The following ${outputFileName} file cannot be read by Json engine"      
       println "JSON_PARSING_ERROR"
	   errorCode "JSON_PARSING_ERROR"
	   return [outputData, errorCode]
    }
 
    errorCode = ''
    return [outputData, errorCode]
}



def GenerateGUID(def data) {
    //println "GUID method called"
    for(int i = 0; i < data.size(); i++) {
	   data[i].GUID = UUID.randomUUID().toString().replaceAll('-','')
	}	
    return data
}

def OverWriteGUID() {
}

def GetStringValue(String colValue) {
    String value = (colValue == null || colValue.trim().length() == 0) ? "" : colValue
	return value
}

//AddBackSlash method used to add forward slashes for ansible command
def AddBackSlash(String path) {
    return path.replaceAll("\\\\","\\\\\\\\")
}

//CheckErrorAfterProcessingJob method used for validation
def CheckErrorAfterProcessingJob(String errorCode) {
    boolean value = false
    if (errorCode != null && errorCode.length() > 0) {
       value = true
       println "Error code is ${errorCode}"
 
       if (errorCode == "FILE_NOT_FOUND") {
          println "File is not available in directory path."
       } else if (errorCode == "NO_DATA") {
          println "File does not contain any content"
       } else if (errorCode == "JSON_PARSING_ERROR") {
          println "Failed to parse json"
       } else if (errorCode == "COMMAND_NOT_FOUND") {
          println "Empty command passed to AppDNA job"
          println "Job Failed to execute..." 
       } else if (errorCode == "ERROR_APPDNA_CONFIG_SETTINGS") {
          println "APPDNA Ansible file location not found. Recheck Config.json"
       } else if (errorCode == "ERROR_EMAIL_CONFIG_MISSING") {
          println "EMAIL Ansible file location not found. Recheck Config.json"         
       } else {
           println "Unknown Error"
       }
    }
 
    return value
}

//CheckRuleToRunCurrentTask method used to get RAG status
def CheckRuleToRunCurrentTask(def statusList, String ragStatus) {   
    def result = false
 
    if (statusList.size() == 0) {
       println "ExectueIfStatus field should not be empty. It must have atleast one Status"      
       return false
    }
 
    if (GetStringValue(ragStatus).length() ==  0) {
       return false
    }
    for(int i = 0;i<statusList.size();i++) {
       if (GetStringValue(ragStatus) == GetStringValue(statusList[i])) {
          result = true          
       }
    }
    return result
}

//GetDateTime method used to get date time stamp
def GetDateTime(String progressIndicator) {
    Date dt = new Date()
    println "The operation ${progressIndicator} at ${dt}"
    return dt 
}

//PrintTmeDifference method used to find time difference between two given dates
def PrintTmeDifference(Date start, Date stop, String taskName) {
    TimeDuration timeDifference = TimeCategory.minus( stop, start )    
    println "The total time ${taskName} takes to complete a process : ${timeDifference}"
}

def CheckLinuxFilePath(String path) {
	if (path.trim().length() > 0 && path.reverse().take(1).reverse() != "/") {
	    path = path + "/"
	}	
	return path
}

def CheckFileExist(String qualifiedFilePathAndName) {
    File srcileile = new File(qualifiedFilePathAndName)
	if (!srcileile.exists() || !srcileile.canRead()) {
	   return false
	}	
	return true
}


/* ================================Common Functions (END)=================================*/

/* ===================Analysis Engine Core Functions (Start)===============================*/

def CheckPreInstallMSIExecuted() {    	
    String fileName = constPreInstallJSONFileName 
	String outputFile = CheckLinuxFilePath(constPreInstallFilePath)	
	boolean isFileExist = CheckFileExist("${outputFile}${fileName}")
	return isFileExist
}

def CheckAnalysisExecuted() {
    String fileName = constAppDNASONFileName 
	String outputFile = CheckLinuxFilePath(constAppDNAFilePath)
	boolean isFileExist = CheckFileExist("${outputFile}${fileName}")
	return isFileExist
}

def CheckSequenceExecuted() {
    String fileName = constSequenceJSONFileName 
	String outputFile = CheckLinuxFilePath(constSequenceJSONFilePath)
	boolean isFileExist = CheckFileExist("${outputFile}${fileName}")
	return isFileExist
}

def CheckRemediationExecuted() {
    String fileName = constRemediationJSONFileName 
	String outputFile = CheckLinuxFilePath(constRemediationJSONFilePath)
	boolean isFileExist = CheckFileExist("${outputFile}${fileName}")
	return isFileExist
}

def PreparingExecuteAnalysis(def data) {
    for(int i = 0; i < data.size(); i++) {
	   String pipeName = GetStringValue(data[i].PipeName)
	   String enable = GetStringValue(data[i].Enable)
       String[] analysisdesiredOutput	= data[i].APPDNADesiredOutput
       String[] sequenceDesiredOutput	= data[i].SEQUENCEDesiredOutput
       String[] remediationDesiredOutput	= data[i].REMEDIATIONDesiredOutput
       String[] launchDesiredOutput	= data[i].LAUNCHDesiredOutput
       String imageName = GetStringValue(data[i].ImageName)	   
       String version = GetStringValue(data[i].Version)	   
       String diffDisk = GetStringValue(data[i].DiffDisk)	   
       String imageType = GetStringValue(data[i].ImageType)	   
       String osName = GetStringValue(data[i].OSName)	   	   
       String osFullName = GetStringValue(data[i].OSFullName)	   
       String directoryName = GetStringValue(data[i].DirectoryName)	   	   
       String msiName = GetStringValue(data[i].PackageName)
       String msiPath = GetStringValue(data[i].PackagePath)
	   String rowStatus = GetStringValue(data[i].ExecutionStatus)
	   String guid = GetStringValue(data[i].GUID)	
	   String logPath = GetStringValue(data[i].LogPath)	   	   
       def dependencies	= data[i].Dependencies
	   String dependency = ''	   
	   
       String serverName = GetStringValue(GetServerName (pipeName))   //copied	   
       String appDNADBName = ''  //GetStringValue(GetAppDNADBInstanceName (pipeName)) //copied	   
	   String packageName = ''
	   String packagePath = ''
       String error = ""
       String packageQualifiedPathAndName =  ""
	   String correlationId = ''
	   String appDNAHostName = serverName
       String jobName =  GetJobExecutionEngineName(pipeName)
	   boolean isPackageValid = true
	   def appStatus
	   
	   println " "
	   println "*********************************************************************************************"
	   println "*                              [${pipeName}]-[${msiName}]                                   *" 
	   println "*********************************************************************************************"	   
	   //println "Identified and locating ${constLauching} Target Server Name - ${serverName}"
	   def appvDependencies = []
	   if (rowStatus == '' || rowStatus == constSUCCESS) {
	   
		   packageQualifiedPathAndName =  "${AddBackSlash(AddBackSlash(msiPath))}${msiName}"
		   packageName = msiName
		   packagePath = "${AddBackSlash(AddBackSlash(msiPath))}"		   

		   if (dependencies.size() > 0) {
			   for(int j = 0;j<dependencies.size();j++) {
			      println "The name is : ${dependencies[j]}"
			      dependency = dependency + "${AddBackSlash(msiPath)}${dependencies[j]}"			  
				  if (j != dependencies.size()-1) {
				     dependency = dependency + ","
				  }				  				
			   }	   	  
		   }
		
		   correlationId = "${guid}"
		   if (isPackageValid) {	   
			  String parentMSIShortName = msiName.take(msiName.lastIndexOf('.'))
			  packageQualifiedPathAndName =  "${AddBackSlash(msiPath)}"
			  String executionStatus = BuildVM(jobName, correlationId, imageName, imageType, osName, version, packageName, diffDisk, packagePath, dependency, serverName)
			  if (CheckErrorAfterProcessingJob(executionStatus)) {
				 isPackageValid = false
			  }

			  (appStatus,error) = GetOutput(correlationId)			  
			  
			  if (GetStringValue(error).length() != 0) {
				 isPackageValid = false
				 data[i].Dependencies = []
			  }
			  if (CheckRuleToRunCurrentTask(launchDesiredOutput, appStatus.Status) && isPackageValid) {
			     //data[i].PackageName = appStatus.AppName
				 //data[i].PackagePath = appStatus.OutputPath
				 //data[i].Dependencies = appvDependencies
			  } else {
				 isPackageValid = false
			  }	   	   
		   }
		   
		   data[i].LogPath = logPath  //apply log path logic
		   if (isPackageValid) {
			  data[i].ExecutionStatus = constSUCCESS
		   } else {
			  data[i].ExecutionStatus = constFAILURE
		   }
		   
		   //Email(appStatus.Status, appStatus.AppName, correlationId)
	   
	   }
       println "========================================COMPLETED============================================"
	}
	
	CreateJsonData(data)
}

def BuildVM(String jobName, String guid, String imageName, String imageType, String osName, String version,String packageName, String diffDisk, String packagePath, String dependency, String serverName) {
   
    String ansibleCommand = BuildVMAnsibleCommand(jobName, guid, imageName, imageType, osName, version, packageName, diffDisk, packagePath, dependency, serverName)
 
    if (ansibleCommand.toUpperCase() == "ERROR_LAUNCHING_CONFIG_SETTINGS" || ansibleCommand.toUpperCase() == "COMMAND_NOT_FOUND") {
        return ansibleCommand.toUpperCase();
    }
 
    println "Triggering ${jobName} Job"
    TriggerJobConditionalWait(jobName, ansibleCommand, true)
    println "Completed..."     
}
 
def BuildVMAnsibleCommand(String jobName, String guid, String imageName, String imageType, String osName, String version, String packageName, String diffDisk, String packagePath, String dependency, String serverName) {
 
   String extraArgument = " -e "
   String ansibleCommand = ""
   //String ansibleValutPath = " --vault-password-file /etc/ansible/project/vault.txt" 
   String ansibleValutPath = " --vault-password-file" 
   String enableLogging = " -vvv"
   String emailFilePathAndName = ""
   String enableAnsibleLog = ""
   boolean isValueExist = true
 
   String vault = ""
                              
   String errCode = "" 
   String outputJsonFileLocation = ""
   String launchYMLQualifiedFileName = ""
   def ansibleConfigDetail

   (ansibleConfigDetail, errCode) = GetConfigurationDetails()

   if (errCode == "ERROR_LAUNCHING_CONFIG_SETTINGS") {
       return errCode
   }

   launchYMLQualifiedFileName = ansibleConfigDetail.ModuleYMLFilePathAndName
   outputJsonFileLocation = ansibleConfigDetail.OutputJsonFileLocation
   emailFilePathAndName = ansibleConfigDetail.EmailYMLFilePathAndName
   enableAnsibleLog = ansibleConfigDetail.EnableAnsibleLog
   vault = ansibleConfigDetail.Vault
    
   ansibleCommand = ansiblePlaybook + ' ' + launchYMLQualifiedFileName
 
   if (imageName.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + '\'' +  "ImageName" + "=" + '"' +  imageName + '"' + '\''
   } else {
      isValueExist = false
   }
 
   if (imageType.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + '\'' +  "ImageType" + "=" + '"' +  imageType + '"' + '\''
   } else {
      isValueExist = false
   }
 
   if (osName.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + '\'' +  "os" + "=" + '"' +  osName + '"' + '\''
   } else {
      isValueExist = false
   }
 
   if (version.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + '\'' +  "version" + "=" + '"' +  version + '"' + '\''
   } else {
      isValueExist = false
   }
 
   if (packageName.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + '\'' +  "package" + "=" + '"' +  packageName + '"' + '\''
   } else {
      isValueExist = false
   }
 
   if (diffDisk.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + '\'' +  "diffdisk" + "=" + '"' +  diffDisk + '"' + '\''
   }
 
   if (packagePath.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "packagepath" + "=" + packagePath
      //ansibleCommand = ansibleCommand + extraArgument + '\'' +  "packagepath" + "=" + '"' +  packagePath + '"' + '\''
   } else {
      isValueExist = false
   }
  
   if (serverName.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + '\'' +  "servername" + "=" + '"' +  serverName + '"' + '\''
   }
  
   if (guid.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + '\'' +  "guid" + "=" + '"' +  guid + '"' + '\''
   } else {
      isValueExist = false
   }
   
   //dependency = ''
   if (GetStringValue(dependency).length() > 0) {
      String[] arrDependencies = dependency.split(',')
	  String tempDependcies = ''
	  if (arrDependencies.size() > 0) {	     
	     for(int i=0;i<arrDependencies.size();i++) {
           String childPackageName = GetStringValue(GetWindowsFileName(arrDependencies[i]))
           if (childPackageName.length() > 0) {
		      tempDependcies = tempDependcies + GetWindowsFileName(childPackageName)
			  if (i != arrDependencies.size()-1 ) {
			     tempDependcies = tempDependcies + ','
			  }
		   }            		   		   		   		     	
		 }
	  }
	  
	  if (GetStringValue(tempDependcies).length() > 0) {
	     ansibleCommand = ansibleCommand + extraArgument + '\'' +  "dependency" + "=" + '"' + tempDependcies + '"' +   '\''
	  }
	  
      //old logic passing along with path 	  
	  //ansibleCommand = ansibleCommand + extraArgument + '\'' +  "dependency" + "=" + dependency + '\''
   }   
   
   if (vault != null && vault.length() > 0) { 
       ansibleCommand = ansibleCommand + ansibleValutPath + " " + vault
   }
   if (enableAnsibleLog != null && enableAnsibleLog.length() > 0 && enableAnsibleLog.toUpperCase() == "YES") { 
       ansibleCommand = ansibleCommand + enableLogging
   }
  
   if (isValueExist) {
      return ansibleCommand
   } else {
      return "COMMAND_NOT_FOUND"   
   }
 
}
  
/* ===================Analysis Engine Core Functions (End)===============================*/

/* ===================Email Engine Core Functions (Start)================================*/

def Email(String overallStatus, String packageName, String guid) {
 
    //println "  "   
    String result = ""

   
    String ansibleCommand = ""
    String jobName = "EMAIL"
	
	println "TRIGGERING EMAIL"
	ansibleCommand = BuildEmailAnsibleCommand(overallStatus,packageName,guid) 
    
    if (ansibleCommand == "ERROR_LAUNCHING_CONFIG_SETTINGS" || ansibleCommand == "COMMAND_NOT_FOUND") {
       return ansibleCommand
    }
	
    TriggerJobConditionalWait(jobName, ansibleCommand, false) 
    println "  "   
    return result
}
 
def BuildEmailAnsibleCommand(String overallStatus, String packageName, String guid) {
   String emailFilePathAndName = ""
   String enableAnsibleLog = ""
   String vault = ""                              
   String errCode = "" 
   String moduleYMLQualifiedFileName = ""
   String outputJsonFileLocation = ""
   def ansibleConfigDetail
   String extraArgument = " -e "
   String ansibleCommand = ""
   String enableLogging = " -vvv"
   def emailProperties
   
   (ansibleConfigDetail, errCode) = GetConfigurationDetails()

   moduleYMLQualifiedFileName = ansibleConfigDetail.ModuleYMLFilePathAndName
   outputJsonFileLocation = ansibleConfigDetail.OutputJsonFileLocation
   emailFilePathAndName = ansibleConfigDetail.EmailYMLFilePathAndName
   enableAnsibleLog = ansibleConfigDetail.EnableAnsibleLog
   vault = ansibleConfigDetail.Vault
   
   ansibleCommand = ansiblePlaybook + ' ' + emailFilePathAndName
   
   (emailProperties,errCode) = GetEmailSettings()

   if (emailFilePathAndName == null && emailFilePathAndName.length() > 0) {
      return "ERROR_EMAIL_CONFIG_MISSING"
   }

 
   if (emailProperties.From != null && emailProperties.From.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "from" + "=" + emailProperties.From
   }
 
   if (emailProperties.To != null && emailProperties.To.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "toemail" + "=" + emailProperties.To 
   }
 
   if (emailProperties.Cc != null && emailProperties.Cc.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "ccemail" + "=" + emailProperties.Cc
   }
 
   if (emailProperties.Bcc != null && emailProperties.Bcc.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "bccemail" + "=" + emailProperties.Bcc
   }
 
   if (emailProperties.Subject != null && emailProperties.Subject.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "emailsubject" + "=" + '"' +  emailProperties.Subject.replaceAll(' ','_') + '"'
   }
 
   if (emailProperties.TemplateName != null && emailProperties.TemplateName.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "templatename" + "=" + emailProperties.TemplateName
   }
 
   if (overallStatus != null && overallStatus.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "status" + "=" + overallStatus
   }
 
   if (packageName != null && packageName.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "package" + "=" + packageName.replaceAll(' ','_')
   }
 
   if (guid != null && guid.length() > 0) {
      ansibleCommand = ansibleCommand + extraArgument + "guid" + "=" + guid
   }
 
   if (enableAnsibleLog != null && enableAnsibleLog.length() > 0 && enableAnsibleLog.toUpperCase() == "YES") { 
       ansibleCommand = ansibleCommand + enableLogging
   }
   //println ansibleCommand
   //return "COMMAND_NOT_FOUND"  
   return ansibleCommand
 
}


/* ===================Email Engine Core Functions (End)==================================*/

/* ===================Triggering Jenkins Job Functions (Start)===========================*/

//TriggerJobConditionalWait method used to trigger jenkins job
def TriggerJobConditionalWait(String jobName, String ansiblePlaybookCommand, boolean isWait) { 
    //println ansiblePlaybookCommand  //only for testing purpose - comment it for prod
    //return                          //only for testing purpose - comment it for prod
    def job = hudson.model.Hudson.instance.getJob(jobName) 
    job.buildersList.clear()
    job.buildersList.add(new Shell("${ansiblePlaybookCommand}")) //without double quotes      
    job.save()
    Date start = GetDateTime("started")
    def build = job.scheduleBuild2(5, new hudson.model.Cause.UserIdCause())
    if (isWait) {
       build.get()
    }
    Date stop = GetDateTime("completed")
    PrintTmeDifference(start, stop, jobName)
}

/* ===================Triggering Jenkins Job Functions (End)=============================*/

/* ===================Json File Reading and Creation Functions (Start)===================*/
def ReadJSon() {

    String fileName =   constReadJsonFileName 
	String outputFile = CheckLinuxFilePath(constReadJsonFilePath)
	def jsondata
	String fileErrorCode = ''
    String errorCode = ''	
    def inputData = []
    def input	
	
	boolean isFileExist = CheckFileExist("${outputFile}${fileName}")
	errorCode = (isFileExist == true) ? '' : "FILE_NOT_FOUND"
	
	if (errorCode.length() > 0) {	   
	   println errorCode
	   return [inputData, errorCode]
	}
	
	(jsondata, fileErrorCode) = ReadOutputFile(outputFile,fileName)	
    if (fileErrorCode == "FILE_NOT_FOUND" || fileErrorCode == "NO_DATA" || fileErrorCode == "JSON_PARSING_ERROR") {
       errorCode = fileErrorCode
    } else {           
	   String pipeName = GetStringValue(jsondata.PipeName)
	   String enablePipe = GetStringValue(jsondata.Enable)
	   def listData = jsondata.Data
	      
	   if (listData == null || listData.size() == 0) {
	      println "ERROR : Data elements should not be empty"
		  errorCode = "EMPTY_DATA_IN_JSON"
		  //currentBuild.result = hudson.model.Result.FAILURE
		  return [inputData, errorCode]
	   }
	   
	   listData.each {
		 def analysisRAG = []
    	 def sequencingRAG = []
		 def remediationRAG = []
		 def launchingRAG = []
		 String imageName = ''
		 String version = ''
		 String diffDisk = ''
		 String imageType = ''												
		 String osName = ''
		 String osFullName = ''
		 String directoryName = ''
		 String packageName = ''
		 String packagePath = ''
		 String executionStatus = ''
		 String guid = ''
		 String logPath = ''
		 def dependencies = []	
         def tempDependencies = it["Dependencies"]
	     def status = it["Status"]

         for(int i = 0;i<status.size();i++) {
            if (status[i].containsKey("APPDNADesiredOutput")) {
			   analysisRAG = []
		       if (status[i].APPDNADesiredOutput.size() > 0) {
			      analysisRAG = status[i].APPDNADesiredOutput			   
			   }
			}
			
			if (status[i].containsKey("SEQUENCEDesiredOutput")) {
			   sequencingRAG = []
		       if (status[i].SEQUENCEDesiredOutput.size() > 0) {			    
			      sequencingRAG = status[i].SEQUENCEDesiredOutput			   
			   }
			}

			if (status[i].containsKey("REMEDIATIONDesiredOutput")) {
		       remediationRAG = []
		       if (status[i].REMEDIATIONDesiredOutput.size() > 0) {
			      remediationRAG = status[i].REMEDIATIONDesiredOutput			   
			   } 
			}

			if (status[i].containsKey("LAUNCHDesiredOutput")) {
		       launchingRAG = []
		       if (status[i].LAUNCHDesiredOutput.size() > 0) {
			      launchingRAG = status[i].LAUNCHDesiredOutput			   
			   }	
            }			
         } //Status for loop
		 imageName = GetStringValue(it["ImageName"])
		 version = GetStringValue(it["Version"])
		 diffDisk = GetStringValue(it["DiffDisk"])
		 imageType = GetStringValue(it["ImageType"])
		 osName = GetStringValue(it["OSName"])
		 osFullName = GetStringValue(it["OSFullName"])
		 directoryName = GetStringValue(it["DirectoryName"])
		 packageName = GetStringValue(it["PackageName"])
		 packagePath = GetStringValue(it["PackagePath"])
		 executionStatus = GetStringValue(it["ExecutionStatus"])
		 guid = GetStringValue(it["GUID"])	
         logPath = GetStringValue(it["LogPath"])

         dependencies = []
		 if (tempDependencies.size() > 0) {
		    dependencies = tempDependencies
		 }		
	     input = [
			PipeName:pipeName,
			Enable:enablePipe,
			APPDNADesiredOutput:analysisRAG,
			SEQUENCEDesiredOutput:sequencingRAG,
			REMEDIATIONDesiredOutput:remediationRAG,
			LAUNCHDesiredOutput:launchingRAG,
			ImageName:imageName,
			Version:version,
			DiffDisk:diffDisk,
			ImageType:imageType,
			OSName:osName,
			OSFullName:osFullName,
			DirectoryName:directoryName,
			PackageName:packageName,
			PackagePath:packagePath,
			Dependencies:dependencies,
            GUID:guid,
			LogPath:logPath,
            ExecutionStatus:executionStatus				
	     ]	   
	   
	     inputData.add(input)
	     //println "new row added in the collection from json"
	     errorCode = ''		 
	   }  //listdata	   
    }

    return [inputData, errorCode]	
}

def CreateJsonData(def data) {
    //println "CreateJsonData called"
	String jsonHeaderString = '{\n'
	String jsonBodyString = ''
	String jsonFooterString = ']\n}'
	
	//jsonBodyString = jsonBodyString + '"' + 'PipeName' + '": ' + '"' + data[0].PipeName + '"' + ',\n'
	//jsonBodyString = jsonBodyString + '"' + 'Enable' + '": ' + '"' + data[0].Enable + '"' + ',\n'
	//jsonBodyString = jsonBodyString + '"Data": [\n'    
	
    for(int i = 0; i < data.size(); i++) {
	    if (i == 0) {
		   jsonBodyString = jsonBodyString + '"' + 'PipeName' + '": ' + '"' + data[i].PipeName + '"' + ',\n'
		   jsonBodyString = jsonBodyString + '"' + 'Enable' + '": ' + '"' + data[i].Enable + '"' + ',\n'
		   jsonBodyString = jsonBodyString + '"Data": [\n'
		   //continue
		}
		jsonBodyString = jsonBodyString + '{\n'
	    jsonBodyString = jsonBodyString + '"' + 'Status' + '": ' + '[' + '\n{'		
		jsonBodyString = jsonBodyString + '"' + 'APPDNADesiredOutput' + '": ' + '[' + '\n'

		for(int j = 0; j < data[i].APPDNADesiredOutput.size(); j++) {
		   jsonBodyString = jsonBodyString + '"' + data[i].APPDNADesiredOutput[j] + '"'
		   if (j != data[i].APPDNADesiredOutput.size()-1) {
		      jsonBodyString = jsonBodyString + ', '
		   }		   
		}
		jsonBodyString = jsonBodyString + ']},'

		jsonBodyString = jsonBodyString + '\n{'
		jsonBodyString = jsonBodyString + '"' + 'SEQUENCEDesiredOutput' + '": ' + '[' + '\n'
		for(int j = 0; j < data[i].SEQUENCEDesiredOutput.size(); j++) {
		   jsonBodyString = jsonBodyString + '"' + data[i].SEQUENCEDesiredOutput[j] + '"'
		   if (j != data[i].SEQUENCEDesiredOutput.size()-1) {
		      jsonBodyString = jsonBodyString + ', '
		   }		   
		}
		jsonBodyString = jsonBodyString + ']},'

		jsonBodyString = jsonBodyString + '\n{'
		jsonBodyString = jsonBodyString + '"' + 'REMEDIATIONDesiredOutput' + '": ' + '[' + '\n'
		for(int j = 0; j < data[i].REMEDIATIONDesiredOutput.size(); j++) {
		   jsonBodyString = jsonBodyString + '"' + data[i].REMEDIATIONDesiredOutput[j] + '"'
		   if (j != data[i].REMEDIATIONDesiredOutput.size()-1) {
		      jsonBodyString = jsonBodyString + ', '
		   }		   
		}
		jsonBodyString = jsonBodyString + ']},'

		jsonBodyString = jsonBodyString + '\n{'
		jsonBodyString = jsonBodyString + '"' + 'LAUNCHDesiredOutput' + '": ' + '[' + '\n'
		for(int j = 0; j < data[i].LAUNCHDesiredOutput.size(); j++) {
		   jsonBodyString = jsonBodyString + '"' + data[i].LAUNCHDesiredOutput[j] + '"'
		   if (j != data[i].LAUNCHDesiredOutput.size()-1) {
		      jsonBodyString = jsonBodyString + ', '
		   }		   
		}
		jsonBodyString = jsonBodyString + ']}\n'
        jsonBodyString = jsonBodyString + '],\n'

		jsonBodyString = jsonBodyString + '"' + 'ImageName' + '": ' + '"' + data[i].ImageName + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'Version' + '": ' + '"' + data[i].Version + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'DiffDisk' + '": ' + '"' + data[i].DiffDisk + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'ImageType' + '": ' + '"' + data[i].ImageType + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'OSName' + '": ' + '"' + data[i].OSName + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'OSFullName' + '": ' + '"' + data[i].OSFullName + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'DirectoryName' + '": ' + '"' + data[i].DirectoryName + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'PackageName' + '": ' + '"' + data[i].PackageName + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'PackagePath' + '": ' + '"' + AddBackSlash(data[i].PackagePath) + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'ExecutionStatus' + '": ' + '"' + data[i].ExecutionStatus + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'GUID' + '": ' + '"' + data[i].GUID + '"' + ',\n'
		jsonBodyString = jsonBodyString + '"' + 'LogPath' + '": ' + '"' + data[i].LogPath + '"' + ',\n'

		if (data[i].Dependencies.size() == 0) {
		   jsonBodyString = jsonBodyString + '"' + 'Dependencies' + '": ' + '[]'
		} else {
		   jsonBodyString = jsonBodyString + '"' + 'Dependencies' + '": ' + '[' + '\n'
           for(int j = 0; j < data[i].Dependencies.size(); j++) {
		      jsonBodyString = jsonBodyString + '"' + data[i].Dependencies[j] + '"'
              if (j != data[i].Dependencies.size()-1) {
			     jsonBodyString = jsonBodyString + ', '
              }			  
		   }
		   jsonBodyString = jsonBodyString + ']\n'		   		
		}
		jsonBodyString = jsonBodyString + '}'
		
		if (i != data.size()-1) {
		   jsonBodyString = jsonBodyString + ',\n'
		} else {
		   jsonBodyString = jsonBodyString + '\n'
		}		
	}
	
	String jsonString = (GetStringValue(jsonBodyString).length() > 0) ? "${jsonHeaderString}${jsonBodyString}${jsonFooterString}" : ""
	println "JSonText"
	println jsonString
	
	if (jsonString == '') {
	   println "ERROR : GENERATING JSON DATA"
	} else {
	   GenerateJsonFile(jsonString)
	}
	 
}

def GenerateJsonFile(String jsonString) {
      String fileName = constOutputJSONFileName
	  String outputFile = CheckLinuxFilePath(constOutputFilePath)
      //outputFile = workspacePath + fileName
      outputFile = outputFile + fileName 
      File fl = new File(outputFile)
      fl.write(jsonString)
}



/* ===================Json File Reading and Creation Functions (End)=====================*/

/* ===================CSV File Reading Functions (Start)=================================*/

def ReadCSV() {

    def outFile    
    def inputData = []
    def input
	String csvFile = workspacePath + pipeConfigData.Input.CSVFileName  
    println "The File Name is " + csvFile	
	int count = 0
	String[] colsHeader = []
	String errorCode = ''
	boolean isValid = true

	boolean isFileExist = CheckFileExist(csvFile)
	errorCode = (isFileExist == true) ? '' : "FILE_NOT_FOUND"

	if (errorCode.length() > 0) {
	   println "csv file is not vaild or not available in the specified location" 
	   println errorCode
	   isValid = false
	   return [inputData, errorCode]
	}	
	
    println "file processed"	
	BufferedReader br = new BufferedReader(new FileReader(csvFile));
	String pipeName = ""	
	String enablePipe = "YES"
	
	//SIVA  Start
	//String getPipeName = ""	
	pipeName = pipeConfigData.PipeName.toUpperCase()
    println "File Pipe Name is ${pipeConfigData.PipeName.toUpperCase()}"	
	pipeName = pPipeName.toUpperCase()	
	println "Parameter Pipe Name is ${pipeName}"
	//SIVA  End	
	
	def osImageDetails
	(osImageDetails, errorCode) = GetOSImageDetails()
	
	if (errorCode.length() > 0) {
	   //println "csv file is not vaild or not available in the specified location" 
	   println errorCode
	   isValid = false
	   return [osImageDetails, errorCode]
	}	

	while ((line = br.readLine()) != null) {		
		count++
		if (colsHeader.size() == 0) {
		   colsHeader = line.split(",")	   
		   if (colsHeader.size() == 0 || colsHeader.size() < noofCSVColumns) {
		       println "ERROR_PROCESSING_CSV_FILE_COLUMN_MISMATCH"
		       println "Column headrers are less than the specified column(${noofCSVColumns})."	
			   isValid = false
			   errorCode = "CSV_COLUMN_MISSING"
			   //println "Exitcolmis"
               return [inputData, errorCode]
		   }		   
		}
		if (count > 1) {
		   String[] cols = line.split(csvColumnSeperator)		   
		   if (cols.size() > 0 && cols.size() < noofCSVColumns) {		       
			   String lastCharater = line[-1..-1]			   
			   if (lastCharater == csvColumnSeperator) { 
		          line = line + ' '
			      cols = line.split(",")				  
			   }
		   }
		   
		   if (cols.size() > 0) {
			   if (cols.size() == noofCSVColumns) {
			   
				  def analysisRAG = []
    			  def sequencingRAG = []
				  def remediationRAG = []
				  def launchingRAG = []
				  String imageName = osImageDetails.ImageName
				  String version = osImageDetails.Version
				  String diffDisk = osImageDetails.DiffDisk
				  String imageType = osImageDetails.ImageType												
				  String osName = osImageDetails.OSName
				  String osFullName = osImageDetails.OSFullName
				  String directoryName = osImageDetails.DirectoryName
				  String packageName = ''
				  String packagePath = ''
				  def dependencies = []
				  
                  //SIVA  Start

			      if (analysisRAG.size() == 0) {
					 //analysisRAG = GetSelectedPipeExpectedRAGStatus(pipeName,constAppAnalysis)
					 analysisRAG = GetExpectedRAGStatus(constAppAnalysis)
					 if (analysisRAG.size() > 0) {
						isValid = (isValid == true) ? true : false
					 } else {
						isValid = false						   
					 }						   				  
				  }
				  					
				  if (sequencingRAG.size() == 0) {
					 //sequencingRAG = GetSelectedPipeExpectedRAGStatus(pipeName,constSequencing)
					 sequencingRAG = GetExpectedRAGStatus(constSequencing)					 					 
					 if (sequencingRAG.size() > 0) {
						isValid = (isValid == true) ? true : false
					 } else {
						isValid = false						   
					 }				  
				  }
				  
				  if (remediationRAG.size() == 0) {
					 //remediationRAG = GetSelectedPipeExpectedRAGStatus(pipeName,constRemediation)	
					 remediationRAG = GetExpectedRAGStatus(constRemediation)					 					 					 
					 if (remediationRAG.size() > 0) {
						isValid = (isValid == true) ? true : false
					 } else {
						isValid = false						   
					 }				  
				  }				  

				  if (launchingRAG.size() == 0) {
					 //launchingRAG = GetSelectedPipeExpectedRAGStatus(pipeName,constLauching)
					 launchingRAG = GetExpectedRAGStatus(constLauching)					 					 					 
					 if (launchingRAG.size() > 0) {
						isValid = (isValid == true) ? true : false
					 } else {
						isValid = false						   
					 }				  
				  }							   				 													
                  
				  for(int x = 0; x < cols.size(); x++) {				    															
					if (colsHeader[x] == "PackageName") { 
					   packageName = ''
					   packageName = GetStringValue(cols[x])	
					   isValid = (isValid == true) ? true : false						   
					}
																						
					if (colsHeader[x] == "PackagePath") { 
					   packagePath = ''						   
					   packagePath = GetStringValue(cols[x])
					   isValid = (isValid == true) ? true : false	
					}
											
					if (colsHeader[x] == "Dependencies") { 	
					   dependencies = []						
					   if (GetStringValue(cols[x]).length() == 0) {
						  //isValid = false							  
					   } else {
						  String[] splitStr = cols[x].split(csvArraySeperator)								  
						  for( String values : splitStr ) {																 
							 if (GetStringValue(values).length() > 0) {
								 dependencies.add(GetStringValue(values))
								 isValid = (isValid == true) ? true : false
							 }							 
						  }
					   }					                
					}                    				
				  } //forloop
				  //SIVA End
				  
				  if (analysisRAG.size() == 0 || sequencingRAG.size() == 0 || remediationRAG.size() == 0 || launchingRAG == 0) {
				     isValid = false
				  }				  
				  
				  if (isValid) {
					 input = [
						PipeName:pipeName,
						Enable:enablePipe,
						APPDNADesiredOutput:analysisRAG,
						SEQUENCEDesiredOutput:sequencingRAG,
						REMEDIATIONDesiredOutput:remediationRAG,
						LAUNCHDesiredOutput:launchingRAG,
						ImageName:imageName,
						Version:version,
						DiffDisk:diffDisk,
						ImageType:imageType,
						OSName:osName,
						OSFullName:osFullName,
						DirectoryName:directoryName,
						PackageName:packageName,
						PackagePath:packagePath,
						Dependencies:dependencies,
                        GUID:UUID.randomUUID().toString().replaceAll('-',''),
						LogPath:'',
                        ExecutionStatus:''				
					]
					//String test1 = "${pipeName}/${enablePipe}"
					inputData.add(input)
                    //println "New row added to collection"					
				  }				  
			   }
		   } else {
		     println "Row data is empty"
			 //println "Exit con"
			 isValid = false
		   }
		}		
	}

	if (!isValid) {
	   //println "Exit1"
	   return [inputData, errorCode]
	}
	
    println "Input file processed and completed...."   
    //println "Exit2"	
	//println "The size of array is " +  inputData.size()
	//println inputData[0]
    return [inputData, errorCode]
}

/* ===================CSV File Reading Functions (End)===================================*/

/* ===================Configuration Function (Start)=====================================*/

def GetJobExecutionEngineName(String pipeName) {
    def data = globalSettingsData
    def configurationProperties	
	def pipeConfig
    String jobEngineName = ""	
	configurationProperties = data.JobExecutionNames
	pipeConfig = data.JobExecutionNames.Pipes
	
	if (configurationProperties == null  && pipeConfig != null) {
	    return jobEngineName
	}
	
    for(int i = 0;i<pipeConfig.size();i++) {
        if (pipeConfig[i].Name.toUpperCase() == pipeName.toUpperCase()) {
            jobEngineName = pipeConfig[i].JobName
        }          
    }
    return GetStringValue(jobEngineName)	
}

def GetCSVConfigurationDetails () {
    String errorCode = ""    
    def data = globalSettingsData    
    def configurationProperties
    def csvConfigDetail  
	String csvDelimiter = ''
	String arrayElementDelimiter = ''
	int noofCSVColumns = 0
        	
	configurationProperties = data.CSVSettings	
	if (configurationProperties != null) {		   
	   csvDelimiter = GetStringValue(configurationProperties.CSVDelimiter).length() == 0 ? ',' : GetStringValue(configurationProperties.CSVDelimiter)
	   arrayElementDelimiter = GetStringValue(configurationProperties.ArrayElementDelimiter).length() == 0 ? ';' : GetStringValue(configurationProperties.ArrayElementDelimiter)	   
	   noofCSVColumns = GetStringValue(configurationProperties.NoOfCSVColumns).isInteger() ?  (GetStringValue(configurationProperties.NoOfCSVColumns) as int) : 0	   

	   if (csvDelimiter == arrayElementDelimiter) {
	      errorCode = "ERROR_CSVDelimiter_SYMBOL_AND_ArrayElementDelimiter_SYMBOL_SHOULD_NOT_SAME"
		  println errorCode
	   } else if (noofCSVColumns == 0) {
		  errorCode = "NO_OF_COLUMNS_SHOULD_NOT_EMPTY"	   
	   } else {
	   }
	} else {
	  errorCode = 'CSV_CONFIGURATION_SETTINGS_MISSING_IN_JSON'	
	}
		
    csvConfigDetail = [
							CSVDelimiter:csvDelimiter,
							CSVArrayElementDelimiter:arrayElementDelimiter,
							NoOfCSVColumns:noofCSVColumns,							
							ErrorCode:errorCode
                      ]    
						  
    return csvConfigDetail         
}


//GetConfigurationDetails method used to ansible module file path,email path and etc from config json based on task name
def GetConfigurationFileLocationDetails () {
    String errorCode = ""    
	String archiveFolderLocation = ""
	String jsonInputFilePath = ""
	String csvInputFileName = ""	
    def data = globalSettingsData    
    def configurationProperties
    def ansibleConfigDetail  
        
	configurationProperties = data.ArchiveFolder
	
	/*if (configurationProperties != null) {
	    archiveFolderLocation = CheckLinuxFilePath(configurationProperties.MoveJSONCSVFile)		
	} else {
	    errorCode = "PATH_MISSING"
	}*/
	
	configurationProperties = data.InputFile
	
	if (configurationProperties != null) {
	    //jsonInputFilePath = CheckLinuxFilePath(configurationProperties.WriteJsonFilePath)  // Change
		csvInputFileName = configurationProperties.CSVSourceFileName
	} else {
	    errorCode = "PATH_MISSING"
	}	

	   
    ansibleConfigDetail = [
							CSVInputFileName:GetStringValue(csvInputFileName),
							ErrorCode:errorCode
                          ]    
						  
    return ansibleConfigDetail         
}

//GetPipeConfigDetails method used to pipe input and output path  from config json based on pipe number
def GetPipeConfigDetails (String pipeName) {
    def data = globalSettingsData
    String pipeConfigPath = ""
	String pipeConfigName = ""
    def configurationProperties
	def pipeDetails
		
	configurationProperties = data.PipesInputOutputPath.Pipes

    for(int i = 0;i<configurationProperties.size();i++) {
        if (configurationProperties[i].Name.toUpperCase() == pipeName.toUpperCase()) {
            pipeConfigPath = configurationProperties[i].PipeSourcePath
			pipeConfigName = configurationProperties[i].PipeSourceName
        }          
    }
	
	pipeDetails = [
	                PipeConfigPath:GetStringValue(pipeConfigPath),
	                PipeConfigName:GetStringValue(pipeConfigName),					
	              ]	
	
    return pipeDetails
}

//GetServerName method used to get server name from config json based on pipe number and task name
def GetServerName (String pipeName) {
    def data = globalSettingsData
    String serverName = ""
    def configurationProperties
	
	//configurationProperties = data.APPDNA.Pipes
	//configurationProperties = data.SEQUENCING.Pipes
	//configurationProperties = data.REMEDIATION.Pipes
	configurationProperties = data.LAUNCHING.Pipes
    for(int i = 0;i<configurationProperties.size();i++) {
        if (configurationProperties[i].Name.toUpperCase() == pipeName.toUpperCase()) {
            serverName = configurationProperties[i].TargetServerName
        }          
    }
    return GetStringValue(serverName)
}

//GetAppDNADBInstanceName method used to get db instance name from config json based on pipe number and task name
def GetAppDNADBInstanceName (String pipeName) {
    def data = globalSettingsData
    String dbInstanceName = ""
    def configurationProperties
	
	//configurationProperties = data.APPDNA.Pipes
	//configurationProperties = data.SEQUENCING.Pipes
	//configurationProperties = data.REMEDIATION.Pipes
	configurationProperties = data.LAUNCHING.Pipes	
    for(int i = 0;i<configurationProperties.size();i++) {
        if (configurationProperties[i].Name.toUpperCase() == pipeName.toUpperCase()) {
            dbInstanceName = configurationProperties[i].DBInstanceName
        }
    }

    return dbInstanceName
}

//SIVA  Start
def GetJobExecutionEngineName1() {
    def data = pipeConfigData.JobExecutionEngineName
    def configurationProperties	= data
    String jobEngineName = ""	
	
	if (configurationProperties == null || GetStringValue(configurationProperties).length() == 0) {
	    return jobEngineName
	}
	
    return GetStringValue(configurationProperties)	
}

def GetOSImageDetails() {
	def configurationProperties = pipeConfigData	
	String imageName = ''
	String version = ''
	String diffDisk = ''
	String imageType = ''												
	String osName = ''
	String osFullName = ''
	String directoryName = ''
	String errorCode = ''
	
	def osImageDetails
			
	if (configurationProperties == null) {
	   errorCode = errorCode + 'Critical inputs are missing in Pipe config file.'	   
	   return [ osImageDetails, errorCode ]	
	}
	
	if (configurationProperties.OSFullName != null && GetStringValue(configurationProperties.OSFullName).length() > 0) {
	   osFullName = GetStringValue(configurationProperties.OSFullName)
	} else {
	   errorCode = errorCode + 'OS Full Name is a required input.'
	}
	
	if (configurationProperties.DirectoryName != null && GetStringValue(configurationProperties.DirectoryName).length() > 0) {
	   directoryName = GetStringValue(configurationProperties.DirectoryName)	
	} else {
	   errorCode = errorCode + 'Directory Name is a required input.'
	}

	if (configurationProperties.OSName != null && GetStringValue(configurationProperties.OSName).length() > 0) {
	   osName = GetStringValue(configurationProperties.OSName)	
	} else {
	   errorCode = errorCode + 'OS Short Name is a required input.'
	}

	if (configurationProperties.Version != null && GetStringValue(configurationProperties.Version).length() > 0) {
	   version = GetStringValue(configurationProperties.Version)	
	} else {
	   errorCode = errorCode + 'Version is a required input.'
	}

	if (configurationProperties.ImageType != null && GetStringValue(configurationProperties.ImageType).length() > 0) {
	   imageType = GetStringValue(configurationProperties.ImageType)	
	} else {
	   errorCode = errorCode + 'ImageType is a required input.'
	}

	if (configurationProperties.ImageName != null && GetStringValue(configurationProperties.ImageName).length() > 0) {
	   imageName = GetStringValue(configurationProperties.ImageName)	
	} else {
	   errorCode = errorCode + 'ImageName is a required input.'
	}

	if (configurationProperties.DiffDisk != null && GetStringValue(configurationProperties.DiffDisk).length() > 0) {
	   diffDisk = GetStringValue(configurationProperties.DiffDisk)		
	}
	
    osImageDetails = [
                            OSFullName:GetStringValue(osFullName), 
                            DirectoryName:GetStringValue(directoryName), 
                            OSName:GetStringValue(osName), 
                            Version:GetStringValue(version),
                            ImageType:GetStringValue(imageType),
                            ImageName:GetStringValue(imageName),
                            DiffDisk:GetStringValue(diffDisk)							
                          ] 
						  
    return [ osImageDetails, errorCode ]	

}

def GetExpectedRAGStatus(String taskName) {
    def data = pipeConfigData.RAGStatus
    def configurationProperties
	
	switch(taskName) {
	   /*case constAppAnalysis:
	        configurationProperties = data.APPDNA
	        break
	   case constSequencing:
	        configurationProperties = data.SEQUENCING
	        break
	   case constRemediation:
	        configurationProperties = data.REMEDIATION
	        break
	   case constLauching:
	        configurationProperties = data.LAUNCHING
	        break*/
       default:
	        break
	}	
	
	def ragStatus = []
	
	if (configurationProperties == null || configurationProperties.size() == 0) {
	   ragStatus.add("GREEN")
	   return ragStatus
	}
    
    return configurationProperties
}
//SIVA End

//GetSelectedPipeExpectedRAGStatus method used to get rag status from config json based on pipe number
def GetSelectedPipeExpectedRAGStatus (String pipeName, String taskName) {
    def data = globalSettingsData
    String serverName = ""
    def configurationProperties
	
	switch(taskName) {
	   case constAppAnalysis:
	        configurationProperties = data.APPDNA.Pipes
	        break
	   case constSequencing:
	        configurationProperties = data.SEQUENCING.Pipes
	        break
	   case constRemediation:
	        configurationProperties = data.REMEDIATION.Pipes
	        break
	   case constLauching:
	        configurationProperties = data.LAUNCHING.Pipes
	        break
       default:
	        break
	}
		
	def ragStatus = []
	
	if (configurationProperties == null) {
	   return ragStatus
	}
	
    for(int i = 0;i<configurationProperties.size();i++) {
        if (configurationProperties[i].Name.toUpperCase() == pipeName.toUpperCase()) {
            if (configurationProperties[i].ExpectedRAGStatus.size() > 0) {
			    for(int j = 0; j < configurationProperties[i].ExpectedRAGStatus.size(); j++) {
				    if (GetStringValue(configurationProperties[i].ExpectedRAGStatus[j]).length() > 0) {
				       ragStatus.add(configurationProperties[i].ExpectedRAGStatus[j])
					}
				}
			}
        }          
    }
    return ragStatus
}



//GetConfigurationDetails method used to ansible module file path,email path and etc from config json based on task name
def GetConfigurationDetails () {
    String moduleYMLFilePathAndName = ""
    String emailYMLFilePathAndName = ""
    String enableAnsibleLog = ""
    String vault = ""
    String errorCode = ""
    String outputJsonFileLocation = ""
	String archiveFolderLoaction = ""
	String csvInputFilePath = ""
    def data = globalSettingsData    
    def configurationProperties
    def ansibleConfigDetail  
    

	//configurationProperties = data.APPDNA
    //errorCode = "ERROR_APPDNA_CONFIG_SETTINGS"
	
	//configurationProperties = data.SEQUENCING
	//errorCode = "ERROR_SEQUENCING_CONFIG_SETTINGS"
	
	//configurationProperties = data.REMEDIATION
	//errorCode = "ERROR_REMEDIATION_CONFIG_SETTINGS"

    //configurationProperties = data.LAUNCHING
    //errorCode = "ERROR_LAUNCHING_CONFIG_SETTINGS"                	
	
    configurationProperties = data.PREVALIDATION
    errorCode = "ERROR_LAUNCHING_CONFIG_SETTINGS"                		
	
    if (configurationProperties == null) {
        ansibleConfigDetail = [
                                ModuleYMLFilePathAndName:moduleYMLFilePathAndName, 
                                OutputJsonFileLocation:outputJsonFileLocation, 
                                EmailYMLFilePathAndName:emailYMLFilePathAndName, 
                                EnableAnsibleLog:enableAnsibleLog,
                                Vault:vault
                              ]
        
        return [ ansibleConfigDetail, errorCode ]   
    }
    
    errorCode = ""
    
    
    if (configurationProperties.YMLFilePathAndName != null && configurationProperties.YMLFilePathAndName.length() > 0) {
        moduleYMLFilePathAndName = configurationProperties.YMLFilePathAndName
    }
    
    if (configurationProperties.Enable_Ansible_Log != null && configurationProperties.Enable_Ansible_Log.length() > 0) { 
        enableAnsibleLog = configurationProperties.Enable_Ansible_Log
    }
    
    if (configurationProperties.OutputJsonFileLocation != null && configurationProperties.OutputJsonFileLocation.length() > 0) { 
        outputJsonFileLocation = CheckLinuxFilePath(configurationProperties.OutputJsonFileLocation)
    }
    
	emailYMLFilePathAndName = ''
    /*if (configurationProperties.Email != null) {
        def email = configurationProperties.Email
        if (email.YMLFilePathAndName != null && email.YMLFilePathAndName.length() > 0) { 
            emailYMLFilePathAndName = email.YMLFilePathAndName
        }
    }*/
    
    /*if (configurationProperties.Vault != null && configurationProperties.Vault.YMLFilePathAandName != null && configurationProperties.Vault.YMLFilePathAandName.length() > 0) {
        vault = configurationProperties.Vault.YMLFilePathAandName
    }*/    	
    
    ansibleConfigDetail = [
                            ModuleYMLFilePathAndName:GetStringValue(moduleYMLFilePathAndName), 
                            OutputJsonFileLocation:GetStringValue(outputJsonFileLocation), 
                            EmailYMLFilePathAndName:GetStringValue(emailYMLFilePathAndName), 
                            EnableAnsibleLog:GetStringValue(enableAnsibleLog),
                            Vault:GetStringValue(vault)
                          ]        
    return [ ansibleConfigDetail, errorCode ]           
}



//GetEmailSettings method used to email settings from config json based on task name
def GetEmailSettings () {
    String from = ""
    String to = ""
    String cc = ""
    String bcc = ""
    String subject = ""
    String templateName = ""
    String errorCode = ""
    def emailProperties
	def data = globalSettingsData
	def configurationProperties
	
	//configurationProperties = data.APPDNA 
    //configurationProperties = data.SEQUENCING 	
	//configurationProperties = data.REMEDIATION 
	//configurationProperties = data.LAUNCHING       
	configurationProperties = data.PREVALIDATION
 
    if (configurationProperties.Email != null) {
        def email = configurationProperties.Email
        if (email.From != null && email.From.length() > 0) {
           from = email.From
        }
           
        if (email.To != null && email.To.length() > 0) {
           to = email.To
        }
           
        if (email.Cc != null && email.Cc.length() > 0) {
           cc = email.Cc
        }
           
        if (email.Bcc != null && email.Bcc.length() > 0) {
           bcc = email.Bcc
        }
           
        if (email.Subject != null && email.Subject.length() > 0) {
           subject = email.Subject
        }
           
        if (email.TemplateName != null && email.TemplateName.length() > 0) {
           templateName = email.TemplateName
        }
    }
    
    emailProperties = [
                         From:GetStringValue(from), 
                         To:GetStringValue(to), 
                         Cc:GetStringValue(cc), 
                         Bcc:GetStringValue(bcc),
                         Subject:GetStringValue(subject),
                         TemplateName:GetStringValue(templateName)
                      ]
        
    return [ emailProperties, errorCode ]
}

/* ===================Configuration Function (End)=======================================*/

/* modified */