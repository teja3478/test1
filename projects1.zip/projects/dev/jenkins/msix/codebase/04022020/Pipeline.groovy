argPipeName = "PIPE1"
argAppType = "MSIX"
pipeline {
    agent any
		
    stages {
        stage('PACKAGE VALIDATION') {
           steps {
				build job: 'PACKAGEVALIDATION', 
                                parameters: [[$class: 'StringParameterValue', name: 'pApplicationTypeName', value: argAppType],
				                   [$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }
        stage('MSIX PACKAGING') {
            steps {
				build job: 'MSIXAutomation', 
                                parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }
        stage('LAUNCH TEST') {
            steps {
				build job: 'MSIX_PUBLISHING', 
                                parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }         
    }
}