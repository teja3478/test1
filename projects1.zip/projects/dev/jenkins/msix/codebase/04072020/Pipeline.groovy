argPipeName = "PIPE1"
argAppType = "MSIX"
pipeline {
    agent any
		
    stages {
        stage('PACKAGE VALIDATION') {
           steps {
				build job: 'MSIX_PACKAGEVALIDATION', 
                                parameters: [[$class: 'StringParameterValue', name: 'pApplicationTypeName', value: argAppType],
				             [$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }
        stage('MSIX PACKAGING') {
            /*steps {
				build job: 'MSIXAutomation', 
                                parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }*/
            steps {
				echo "MSIX packaging not implemented"
            }
        }
        stage('LAUNCH TEST') {
            steps {
				build job: 'MSIX_PUBLISHING', 
                                parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }         
    }
}