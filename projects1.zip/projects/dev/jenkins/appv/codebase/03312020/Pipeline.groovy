argPipeName = "PIPE1"
argAppType = "APPV"
pipeline {
    agent any
		
    stages {
        stage('PACKAGE VALIDATION') {
            steps {
				build job: 'PACKAGEVALIDATION', 
                                parameters: [[$class: 'StringParameterValue', name: 'pApplicationTypeName', value: argAppType],
				             [$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }
        stage('COMPATIBILITY TEST') {
            steps {
				build job: 'ANALYZE', parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }
        stage('SEQUENCING') {
            steps {
				build job: 'SEQUENCING', parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }
        stage('REMEDIATION') {
            steps {
				build job: 'REMEDIATION', parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }        
        stage('LAUNCH TEST') {
            steps {
				build job: 'PUBLISHING', parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName]]
            }
        }         
    }
}
