argPipeName = "PIPE1"
argAppType = "APPV"
argConfigFile = "/etc/ansible/projects/dev/jenkins/appv/config/jenkins_config.json"
argStageName = ""

pipeline {
    agent any
		
    stages {
        stage('PACKAGE VALIDATION') {
            steps {
				build job: 'PACKAGEVALIDATION', 
				parameters: [[$class: 'StringParameterValue', name: 'pApplicationTypeName', value: argAppType],
				             [$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile]]							 
				script {
				    argStageName = "PACKAGEVALIDATION"
				}							 
            }
        }
        stage('COMPATIBILITY TEST') {
            steps {
				build job: 'APPV_ANALYZE', 
				parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile],
							 [$class: 'StringParameterValue', name: 'pLastExecutedStep', value: argStageName]]
				script {
				    argStageName = "APPDNA"
				}							 
            }
        }
        stage('SEQUENCING') {
            steps {
				build job: 'APPV_SEQUENCING', 
				parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile],
							 [$class: 'StringParameterValue', name: 'pLastExecutedStep', value: argStageName]]
				script {
				    argStageName = "SEQUENCING"
				}							 
            }
        }
        stage('REMEDIATION') {
            steps {
				build job: 'APPV_REMEDIATION', 
				parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile],
							 [$class: 'StringParameterValue', name: 'pLastExecutedStep', value: argStageName]]
				script {
				    argStageName = "REMEDIATION"
				}							 
            }
        }        
        stage('LAUNCH TEST') {
            steps {
				build job: 'APPV_PUBLISHING', 
				parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile],
							 [$class: 'StringParameterValue', name: 'pLastExecutedStep', value: argStageName]]
				script {
				    argStageName = "LAUNCHING"
				}							 
            }
        }         
    }
}
