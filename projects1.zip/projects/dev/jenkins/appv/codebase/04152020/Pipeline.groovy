argPipeName = "PIPE1"
argAppType = "APPV"
argConfigFile = "/etc/ansible/projects/dev/jenkins/appv/config/jenkins_config.json"

pipeline {
    agent any
		
    stages {
        stage('PACKAGE VALIDATION') {
            steps {
				build job: 'PACKAGEVALIDATION', 
				parameters: [[$class: 'StringParameterValue', name: 'pApplicationTypeName', value: argAppType],
				             [$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile]]
            }
        }
        stage('COMPATIBILITY TEST') {
            steps {
				build job: 'APPV_ANALYZE', 
				parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile]]
            }
        }
        stage('SEQUENCING') {
            steps {
				build job: 'APPV_SEQUENCING', 
				parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile]]
            }
        }
        stage('REMEDIATION') {
            steps {
				build job: 'APPV_REMEDIATION', 
				parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile]]
            }
        }        
        stage('LAUNCH TEST') {
            steps {
				build job: 'APPV_PUBLISHING', 
				parameters: [[$class: 'StringParameterValue', name: 'pPipeName', value: argPipeName],
							 [$class: 'StringParameterValue', name: 'pConfigurationFile', value: argConfigFile]]
            }
        }         
    }
}
