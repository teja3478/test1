﻿        #ansible-playbook email.yml -vvv --extra-vars '{"package":"firefox","status":"red","toemail":"harini.kapila@wipro.com","ccemail":"bhuvaneswari.maddi@wipro.com","emailsubject":"appdna_report","guid":"23567890","bccemail":"bhuvaneswari.maddi@wipro.com"}'
        #$arguments = @()
        #$arguments = "package:firefox","status:red","toemail:harini.kapila@wipro.com","ccemail:bhuvaneswari.maddi@wipro.com","emailsubject:appdna_report","guid:23567890","bccemail:bhuvaneswari.maddi@wipro.com"
        
        Set-ExecutionPolicy -ExecutionPolicy Unrestricted
        $template="C:/Project/Email/AppDNA/EmailJsonTemplate.json"       
        $jsonfile="C:/Project/Email/AppDNA/EmailJson.json"
        $folderpath="C:/Project/Email/AppDNA/Output"
        write-host($template)
        write-host($jsonfile)
        $attachmentName=$args[0]
        $appName=$args[0].replace("_"," ")
        $attachment=$args[0]+".mht"
        $guid=$args[5]
       
        $status=$args[1]
        
        Write-Host($args[3])
        $output = "[{'App Name':'$appName','Overall Rag':'$status'}]"
        $ToEmail=$args[2]
        $CCEmail=$args[3]
        #$BCCEmail=$args[6]
        $Subject=$args[4].replace("_"," ")
        Write-Host($args[4])
        Write-Host($args[5])
        Write-Host("Status is :$status")
        if($status -eq "red" -or $status -eq "amber")
        {
         Copy-Item  -Path $template -Destination $jsonfile -Recurse -force              
          $reportPath=$folderpath+"/"+$guid+".mht"
        # $reportPath="C:\Project\Email\AppDNA\Output\"+$guid+".mht"
        $var = [convert]::ToBase64String((get-content $reportPath -encoding byte))        
        $MailAttachment="[{'$attachment':'$var'}]" 

        ((Get-Content -path $jsonfile -Raw) -replace 'MailAttachment', $MailAttachment ) | Set-Content -Path $jsonfile
        }
         else
         { 
           Copy-Item  -Path $template -Destination $jsonfile -Recurse -force              
        $reportPath1="C:\cygwin64\etc\ansible\blank.mht"
        $var = [convert]::ToBase64String((get-content $reportPath1 -encoding byte))        
        $MailAttachment="[{'$attachment':'$var'}]" 

        ((Get-Content -path $jsonfile -Raw) -replace 'MailAttachment', $MailAttachment ) | Set-Content -Path $jsonfile
        
         }
               
         $output = "[{'App Name':'$appName','Overall Rag':'$status'}]"
        $status=$args[1]
        $ToEmail=$args[2]
        $CCEmail=$args[3]
        #$BCCEmail=$args[6]
        $Subject=$args[4].replace("_"," ")
        Write-Host($args[4])
        Write-Host($args[5])
        ((Get-Content -path $jsonfile -Raw) -replace 'ToEmail',$ToEmail) | Set-Content -Path $jsonfile
        ((Get-Content -path $jsonfile -Raw) -replace 'CCEmail',$CCEmail) | Set-Content -Path $jsonfile
        #((Get-Content -path $jsonfile -Raw) -replace 'bccemail',$BCCEmail) | Set-Content -Path $jsonfile
        ((Get-Content -path $jsonfile -Raw) -replace 'emailsubject',$Subject) | Set-Content -Path $jsonfile
        ((Get-Content -path $jsonfile -Raw) -replace 'dynamicdata1', $output ) | Set-Content -Path $jsonfile
        $var1 = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("admin:ee05eaaba7b76f16e285d983d605c9bf"))
        iwr http://10.214.81.35:8000/wexflow/startWithVariables -Method 'POST' -Headers @{ 'Authorization' = 'Basic ' + $var1 } -Body  (Get-Content -path $jsonfile -Raw)
     
                 
         
   
       