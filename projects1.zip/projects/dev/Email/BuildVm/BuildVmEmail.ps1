﻿        # ansible-playbook email.yml -vvv --extra-vars '{"package":"buildvm","status":"green","toemail":"harini.kapila@wipro.com","ccemail":"bhuvaneswari.maddi@wipro.com","emailsubject":"BuildVm_report","guid":"0aeab38160854668b6New006"}'
        # ansible-playbook email.yml -vvv --extra-vars '{"package":"buildvm","status":"green","toemail":"harini.kapila@wipro.com","ccemail":"bhuvaneswari.maddi@wipro.com","emailsubject":"BuildVm_report","guid":"0aeab38160854668b6New006","bccemail":"bhuvaneswari.maddi@wipro.com","outputpath":"\\\\VDIAASLABSRV101\\AnsibleOutput\\"}'
        # ansible-playbook email.yml -vvv --extra-vars '{"package":"buildvm","status":"red","toemail":"harini.kapila@wipro.com","ccemail":"bhuvaneswari.maddi@wipro.com","emailsubject":"Build_report","guid":"launched","bccemail":"bhuvaneswari.maddi@wipro.com","outputpath":"\\\\VDIAASLABSRV101\\AnsibleOutput\\"}'

        #$arguments = "package:firefox","status:red","toemail:harini.kapila@wipro.com","ccemail:bhuvaneswari.maddi@wipro.com","emailsubject:appdna_report","guid:23567890","bccemail:bhuvaneswari.maddi@wipro.com"
        
        Set-ExecutionPolicy -ExecutionPolicy Unrestricted
        $template="C:/Project/Email/BuildVm/EmailJsonTemplate.json"
        $jsonfile="C:/Project/Email/BuildVm/EmailJson.json"
        $folderpath="C:/Project/Email/BuildVm/Output"
        write-host($template)
        write-host($jsonfile)
        $attachmentName=$args[0]
        $appName=$args[0].replace("_"," ")
        $attachment=$args[0]+".png"
        $guid=$args[5]       
        $status=$args[1]        
        Write-Host($args[3])
        $output = "[{'App Name':'$appName','Overall Rag':'$status'}]"
        $ToEmail=$args[2]
        $CCEmail=$args[3]
       # $BCCEmail=$args[8]        
        $outputpath=$args[6]
        $fldrDate=$args[7]
        $Subject=$args[4].replace("_"," ")
        Write-Host($args[4])
        Write-Host($args[5])
        Write-Host($args[6])
        Write-Host($args[7])
        Write-Host("Status is :$status")
        if($status -eq "red" -or $status -eq "amber")
        {
         Copy-Item  -Path $template -Destination $jsonfile -Recurse -force              
        $reportPath=$outputpath+$fldrDate+'\'+$guid+'\'+'buildvm'+'\'+'Notlaunched.png'

         #$reportPath="C:\cygwin64\etc\ansible\Notlaunched.png"
        $var = [convert]::ToBase64String((get-content $reportPath -encoding byte))        
        $MailAttachment="[{'$attachment':'$var'}]" 

        ((Get-Content -path $jsonfile -Raw) -replace 'MailAttachment', $MailAttachment ) | Set-Content -Path $jsonfile
        }
         else
                { 
           Copy-Item  -Path $template -Destination $jsonfile -Recurse -force 
           $reportPath1=$folderpath+"/"+$guid+".png"
         #$reportPath1="C:\Project\file\"+$guid+".png"         
          #$reportPath1="$outputpath+$fldrDate+'\'+$guid+'\'+'buildvm'+'\ '+$guid+'.png"
          # $reportPath1="C:\cygwin64\etc\ansible\"+$guid+".png"
           $var = [convert]::ToBase64String((get-content $reportPath1 -encoding byte))       
        $MailAttachment="[{'$attachment':'$var'}]" 
        ((Get-Content -path $jsonfile -Raw) -replace 'MailAttachment', $MailAttachment ) | Set-Content -Path $jsonfile        
         }               
         $output = "[{'App Name':'$appName','Overall Rag':'$status'}]"
        $status=$args[1]
        $ToEmail=$args[2]
        $CCEmail=$args[3]
       # $BCCEmail=$args[8]
        $Subject=$args[4].replace("_"," ")
        Write-Host($args[4])
        Write-Host($args[5])
       # Write-Host($args[8])
        ((Get-Content -path $jsonfile -Raw) -replace 'toemail',$ToEmail) | Set-Content -Path $jsonfile
        ((Get-Content -path $jsonfile -Raw) -replace 'ccemail',$CCEmail) | Set-Content -Path $jsonfile
        #((Get-Content -path $jsonfile -Raw) -replace 'cccemail',$BCCEmail) | Set-Content -Path $jsonfile
        ((Get-Content -path $jsonfile -Raw) -replace 'emailsubject',$Subject) | Set-Content -Path $jsonfile
        ((Get-Content -path $jsonfile -Raw) -replace 'dynamicdata1', $output ) | Set-Content -Path $jsonfile
        $var1 = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("admin:ee05eaaba7b76f16e285d983d605c9bf"))
        iwr http://10.214.81.35:8000/wexflow/startWithVariables -Method 'POST' -Headers @{ 'Authorization' = 'Basic ' + $var1 } -Body  (Get-Content -path $jsonfile -Raw)
     
                 
         
   
       