﻿
$filepath = "D:\AnsibleOutput\"
$datefolder=$filepath+$args[0]
If(!(test-path $datefolder ))
{
   New-Item -ItemType Directory -Force -Path $datefolder
}
    $guidFolder= $datefolder+"\"+$args[1]

If(!(test-path $guidFolder))
{
    New-Item -ItemType Directory -Force -Path $guidFolder
}

$FolderToCreate =$guidFolder+"\buildVM\"
Write-Host("final folder to be created is $FolderToCreate")
If(!(test-path $FolderToCreate))
{
    New-Item -ItemType Directory -Force -Path $FolderToCreate
}

    