Param(
[string]$packagepath,
[string]$folderdate,
[string]$guid,
[string]$filepath
)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
#$filepath = "\\VDIAASLABSRV101\logs\"
$f=$packagepath.substring($packagepath.LastIndexOf("\")+1)
$filename=$f.Split(".")
$appvname=$filename[0]+".appv"
#$image1name=$filename[0]+"_1.png"
#$image2name=$filename[0]+"_2.png"
$imagepath = "C:\printscreen.png"
$filefound=dir -Path $imagepath -Filter printscreen.png -Recurse | %{$_.FullName}
Write-Host("Validating if the image1 was created : $filefound")
$status='Red'
if($filefound -ne '')
{ $status='Green' }     
$outputjson="C:\packages\output.json"
$outputtemplate="C:\packages\outputTemplate.json"
$currentguid=($guid.split("_"))[0]
$Folder=$filepath+$folderdate+"\"+$currentguid+"\launch\"
$Folder=$Folder.Replace("\","\\")
Copy-Item  -Path $outputtemplate -Destination $outputjson -Recurse -force
((Get-Content -path $outputjson -Raw) -replace 'APPV',$appvname) | Set-Content -Path $outputjson
((Get-Content -path $outputjson -Raw) -replace 'Status',$status) | Set-Content -Path $outputjson
((Get-Content -path $outputjson -Raw) -replace 'val',$Folder) | Set-Content -Path $outputjson

