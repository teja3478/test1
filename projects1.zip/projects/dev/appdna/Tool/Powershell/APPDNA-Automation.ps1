﻿#ansible-playbook /etc/ansible/BuildAutomation/appdna/AppDNA.yml -e os="Windows 10" -e msi=/etc/ansible/project/inputmsifiles/vlc.msi -e guid=configfilechanged001 -e AppDNARemotehost=vdilabhp120-4 -e servername=VDILABHP120-4 -e AppDNADBIdentifier="VDILABHP120-4:AppDNADB
Param(
[string]$msiInput,
[string]$platform,
[string]$guid,
[string]$AppDNAremotehost,
[string]$toolsetupmachine,
[string]$APPDNADBIdentifier,
[string]$msiinputpath,
[string]$dependency
)


$configjson = ConvertFrom-Json(Get-Content 'C:\Projects\AppDNA\Tool\Powershell\config.json' -Raw)
 $inputFile=($configjson.'inputFile').Trim()
 $inputjsonTemplate=($configjson.'inputjsonTemplate').Trim()
 $ApplistFileTemplate=($configjson.'ApplistFileTemplate').Trim()
 $csvPath= ($configjson.'csvPath').Trim()
 $msiPath=($configjson.'msiPath').Trim()
 $reportPath= ($configjson.'Reportspath').Trim()
 $AppDNAConfigpath=($configjson.'AppDNAConfigpath').Trim()
 $AppDNAlnk=($configjson.'AppDNAlnk').Trim()
 $Emailtemplate=($configjson.'Emailtemplate').Trim()
 $Emailjsonfile=($configjson.'Emailjsonfile').Trim()
 $logspath=($configjson.'logspath').Trim()
 $logsarchivepath=($configjson.'logsarchivepath').Trim()
 $appdnaarchivefolderpath=($configjson.'appdnaarchivefolderpath').Trim()

Function restartservice([string]$serviceName){
Get-Service $serviceName |Where {$_.status –eq 'Stopped'} | Start-Service
$serviceStatus=(Get-Service $serviceName).Status
Write-Host("Status of $serviceName :")
Write-Host($serviceStatus)

}
function createspecificFolder([string]$foldername)
{
    Write-host("$foldername")
	$basefolder = $reportPath +"\"+$guid+"\"+"appdna"
	 If(!(test-path $basefolder))
    {
          New-Item -ItemType Directory -Force -Path $basefolder

    }
    
    Write-Host("Base Folder created is :$FolderToCreate")
   #return $FolderToCreate
}

function createFolder([string]$basepath,[string]$foldername)
{
    Write-host("$foldername")
    $exportFilePath=($foldername.Split("\"))
    $pathsize=$exportFilePath.Length
    $pathsize=$pathsize-1
    $exportFile=($exportFilePath[$pathsize].Split("."))
    Write-Host($exportFile[0])
    $FolderToCreate=$basepath+"\"+($exportFile[0].Trim())

    If(!(test-path $FolderToCreate))
    {
          New-Item -ItemType Directory -Force -Path $FolderToCreate

    }

    Write-Host("Folder created is :$FolderToCreate")
   #return $FolderToCreate
}


function updateXMLConfig([string]$moduleName,[string]$Folder, [string]$remotehost, [string]$dbidentifierval)
{
    $ConfigFile = $AppDNAConfigpath 
    $XPath = "configuration/appSettings/add[@key='Modules']"
    $Attribute = "value"
    $moduleName = $jsonobj.Platform
    $xml = [xml](Get-Content -Path $ConfigFile)
    $xml.SelectSingleNode($XPath).SetAttribute($Attribute, $moduleName)
    $AppDnaReportpath = "configuration/appSettings/add[@key='AppDnaReportpath']"
    $Attribute2 = "value"
    Write-Host("Module Name :$moduleName")
    Write-Host("Folder Name :$Folder")
    Write-Host("RemoteHostName: $AppDNAremotehost")
	Write-Host("DBIdentifier: $APPDNADBIdentifier")
    Write-Host("Before updating Report Path..")
    #$xml.SelectSingleNode($ReportPath).SetAttribute($Attribute2,"\\VDILABHP120-3\Reports")
    $xml.SelectSingleNode($AppDnaReportpath).SetAttribute($Attribute2,  $Folder)
    $ModuleAlgo = "configuration/appSettings/add[@key='AddAlgoModules']"
    $Attribute3 = "value"
    $xml.SelectSingleNode($ModuleAlgo).SetAttribute($Attribute3, $moduleName)
    #$RemoteHostName = "configuration/appSettings/add[@key='RemoteHostName']"
   # $Attribute4 = "value"
    #$xml.SelectSingleNode($RemoteHostName).SetAttribute($Attribute4, $remotehost)
    $DBIdentifier = "configuration/appSettings/add[@key='DBIdentifier']"
    $Attribute5 = "value"
    $xml.SelectSingleNode($DBIdentifier).SetAttribute($Attribute5, $dbidentifierval)
    $xml.Save($ConfigFile)
}

function triggerAppDNA([string]$logsfldr,[string]$logsarchivefldr)
{
    $shortcut = $AppDNAlnk
    write-host("Initiating the Start Process...")
    Start-Process -FilePath $shortcut -WindowStyle Hidden -Verb RunAs administrator
	$process=Get-Process -Name "ImportAnalyzeExport"
    write-host $process.Name
    Write-host "INFO: APP DNA analysis in progress.....Please Wait" -ForegroundColor White -BackgroundColor Black
   
    while($process)
      {
        Start-Sleep -Seconds 1
		$process=Get-Process -Name "ImportAnalyzeExport" -Verbose -ErrorAction SilentlyContinue
		Write-host "INFO: ImportAnalyzeExport process triggered"
      }  
	  $logfile=dir -Path $logsfldr -Filter *.log -Recurse | %{$_.FullName}
	  Write-host("logfile  $logfile")
	  $logdata=Get-Content $logfile
	  Write-Host("AppDNA Logs : $logdata")
	  #Move-Item $logsfldr -Destination $logsarchivefldr -force ( not requitred)
      Sleep -Seconds 30

}
function getStatus([string] $StatusFolder,[string]$guid,[string]$serverName )
{
   
    Write-Host("Initiated export Results function")
    Write-Host($StatusFolder)
    $fileContent=@()
    Write-Host("Updating the Output XML, by replacing the APPID to GUID")
    #$CSVLFile ="\\WIN-T5KQ7K2POGM\InputFiles\Reports\"+$host+"_AppDNAReport.csv" 
    $CSVLFile =$StatusFolder+"\"+$serverName+"_AppDNAReport.csv"
    Write-Host($CSVLFile)
    $fileContent = Import-csv $CSVLFile
   # $fileContent.'AppID' = $AppID
    #$finalStatus=$fileContent."Overall Rag"
    $jsonoutput= ConvertTo-Json($fileContent)
    $outputFile=$StatusFolder+"\"+$guid+".json"
    $jsonoutput | Out-File $outputFile
    return $jsonoutputpath
}

 
 $now= Get-Date -DisplayHint DateTime
 $now1=((([string]$now).Replace("/", "")).Replace(" ","_")).Replace(":","")
<#  $process1=Get-Process -Name "ImportAnalyzeExport" -ErrorAction SilentlyContinue

 if($process1)
 {
		Write-Host("AppDNA Automation Setup is already Running .... stopping the process")
		Stop-Process -Name "ImportAnalyzeExport" -Force
 }
 else{
		Write-Host("No AppDNA Automation Setup is  Running .... ")
 } #>
Get-ChildItem $logspath | Remove-Item -Recurse -Force
Write-Host("Info: Removed old logs ...")
Write-Host("Copying the json Template to ensure, old data is not retained")
Copy-Item  -Path $inputjsonTemplate -Destination $inputFile -Recurse -force

$json = ConvertFrom-Json(Get-Content $inputFile -Raw)
$msifilename=$msiInput
$MSIName=$msifilename.substring($msifilename.LastIndexOf("\")+1)
$json.'MSI' =$msiPath+$MSIName
$json.'Platform' =$platform

if($dependency -ne '')
 {
    
    Write-host("Dependent MSIs :$dependency ")
    
    [hashtable]$data = @{}
    $childelements=$dependency.Split(",")
    $subchild = @()
    foreach($childel in $childelements)
    {
         #$c=$childelements[$i]
         $childName=$childel.substring($childel.LastIndexOf("\")+1) 
         Write-Host("Child is :", $msiPath+$childName)  
         $subchild += [pscustomobject]@{
         'child'=$msiPath+$childName
         }
    }
    Write-host("consolidated subchild is :",$subchild)
   $json.'dependency'=$subchild
}
$json |convertto-json -depth 4 |Out-File $inputFile
 
 foreach($jsonobj in $json)
 {
   $msi=$null
   $parent=$null
  
    $msi=$jsonobj.MSI
    $parent=$jsonobj.MSI
    $moduleName = $jsonobj.Platform
   

    $child=$jsonobj.dependency
    if($child -ne "-")
    {
       Write-Host("Dependency exists")
       $depchild=''
        $childelements=$dependency.Split(" ")
       foreach($childobj in $childelements)
       {
         $childName=$childobj.substring($childobj.LastIndexOf("\")+1) 
         Write-Host("Child is :", $msiPath+$childName)  
         $depchild = ($msiPath+$childName)
        $msi=$msi+","+$depchild
       }
       
       #((Get-Content -path $inputFile -Raw) -replace 'dependency',$child) | Set-Content -Path $inputFile
       #$msi=$msi+$depchild

    }
        Write-Host("Final MSI Name is ")
        Set-ExecutionPolicy -ExecutionPolicy Unrestricted
        Write-Host($msi)

        $folderName=''
        $pathsize=($parent.Split("\")).Length
        $pathsize=$pathsize-1
		$basefolder = $reportPath +"\"+$guid+"\"+"appdna"
		If(!(test-path $basefolder))
		{
			  New-Item -ItemType Directory -Force -Path $basefolder

		}
		
		Write-Host("Base Folder created is :$FolderToCreate")
		
        Write-Host("creating folderName in which the reports will be updated")
        $folderName= $basefolder+"\"+(($parent.Split("\"))[$pathsize].Split("."))[0]
          
        createFolder $basefolder $parent
         
        Write-Host("Updating the COnfig File with Module Name and THe Reports update $folderName")   
        $remotehostname=$AppDNAremotehost
		$dbidentifiername=$APPDNADBIdentifier
        updateXMLConfig $moduleName $folderName $remotehostname $dbidentifiername
       
        Copy-Item  -Path $ApplistFileTemplate -Destination $csvPath -Recurse -force
        $msi | foreach { Add-Content -Path $csvPath -Value "$_" }

        Write-Host("Triggering APP DNA")
        triggerAppDNA $logspath $logsarchivepath

        Write-Host("Exporting the results")
        
        $body=(($parent.Split("\"))[$pathsize].Split("."))[0]
		$target=$toolsetupmachine
		#$guid=$args[2]
        $status=getStatus $folderName $guid $target

        #email $folderName $body $status
        
        $destReportFolder=$guid
        #Move-Item $folderName -Destination $destReportFolder -force
       # $host=.\HOSTNAME.EXE
        $outputcsv=$folderName+"\"+$target+"_AppDNAReport.csv"
		
		
		$destpath=$reportPath+"\"+$guid+".csv"
        Copy-Item $outputcsv -Destination  $destpath
        $fileContent=(Import-Csv ($outputcsv))
        $jsonoutput= ConvertTo-Json($fileContent)
        $outputFile=$reportPath+"\"+$guid+".json"
        $jsonoutput | Out-File $outputFile
        $mhtpath=$basefolder+"\"+$guid+".mht"
        $reppath= $folderName+"\RemediationReports"
		
		
		#$now= Get-Date -DisplayHint DateTime
		#$now1=((([string]$now).Replace("/", "")).Replace(" ","_")).Replace(":","")
        #$fldr=$folderName+"_analysed"
		#Move-Item $folderName -Destination $fldr -force
		#Move-Item $fldr -Destination $basefolder -force
		
       <#  if($status -ne 'Green')
        {
            $mhtFile=dir -Path $reppath -Filter *.mht -Recurse | %{$_.FullName}
            Move-Item $mhtFile -Destination $mhtpath -force
        }
        else
        {
            Write-Host("Remediation Report will not be generated if the Status is Green")
        }
        $now= Get-Date -DisplayHint DateTime
        $now1=((([string]$now).Replace("/", "")).Replace(" ","_")).Replace(":","")
        $fldr=$folderName+$now1
        Move-Item $folderName -Destination $fldr -force
        Move-Item $fldr -Destination $appdnaarchivefolderpath -force #>
	    
	

         
}