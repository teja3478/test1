$process=Get-Process -Name "ImportAnalyzeExport"
    write-host $process.Name
    Write-host "INFO: APP DNA analysis in progress.....Please Wait" -ForegroundColor White -BackgroundColor Black
   
   write-host("process parameter called before loope")
   write-host $process
    while($process)
      {
	   write-host("inside while loop")
	   write-host $process
        Start-Sleep -Seconds 1
		$process=Get-Process -Name "ImportAnalyzeExport" -Verbose -ErrorAction SilentlyContinue
		write-host("after triggering process")
		write-host $process
		Write-host "INFO: ImportAnalyzeExport process triggered"
		
		
      }  
	    write-host("process parameter called after loop")
   write-host $process
   write-host ("comments completed")
   $configjson = ConvertFrom-Json(Get-Content 'C:\Projects\AppDNA\Tool\Powershell\config.json' -Raw)
    $logspath=($configjson.'logspath').Trim()
 $logsarchivepath=($configjson.'logsarchivepath').Trim()
	  $logfile=dir -Path $logspath -Filter *.log -Recurse | %{$_.FullName}
	  Write-host("logfile  $logfile")
	  $logdata=Get-Content $logfile
	  Write-Host("AppDNA Logs : $logdata")
	  #Move-Item $logsfldr -Destination $logsarchivefldr -force ( not requitred)
      Sleep -Seconds 30