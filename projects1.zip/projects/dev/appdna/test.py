import wmi
import os
import glob
import time
import xlrd
import datetime
 
  


username='admin'
pwd='wipro@123'
conn = wmi.WMI()


conn = wmi.WMI('10.156.38.131', user=username, password=pwd)
temp = "C:\psexec.exe -accepteula -nobanner -i 2 -s cmd /c notepad.exe"
conn.Win32_Process.Create(CommandLine=temp)

