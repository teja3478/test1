﻿
Param(

    [Parameter(Mandatory=$True)]

    $msixpath,
    
    [Parameter(Mandatory=$True)]
    $vhdpath

)

#$msixpath = $msixpath.replace("\\","\")
#$vhdpath = $vhdpath.replace("\\","\")
$parentfolder = [System.IO.Path]::GetFileNameWithoutExtension($msixpath)
$vhdpath = $vhdpath+"$parentfolder.VHD"
if (Test-path $vhdpath) {
if(Get-VHD -Path $vhdpath){

Dismount-VHD -Path $vhdpath -Verbose
start-sleep 5
Remove-Item  $vhdpath -force -Verbose

}
else{
    Remove-Item  $vhdpath -force 
    }
}

if(Get-Module -ListAvailable -name Hyper-V) {
    Write-Host "For Creating VHD Hyper-V module is installed...." -ForegroundColor Green

#Creating New VHD

New-VHD -SizeBytes 2GB -Path $vhdpath -Dynamic -Confirm:$false -Verbose

$vhdObject = Mount-VHD $vhdpath -Passthru -Verbose

$disk = Initialize-Disk -Passthru -Number $vhdObject.Number -Verbose

$partition = New-Partition -AssignDriveLetter -UseMaximumSize -DiskNumber $disk.Number -Verbose

$format= Format-Volume -FileSystem NTFS -Confirm:$false -DriveLetter $partition.DriveLetter -Force -Verbose

#########

#Getting Mounted New VHD drive path letter

$driveletter=$format.DriveLetter

$drivepath = $driveletter + ":"

#########

#Changing directory to msixmgr

CD "C:\Program Files\msixmgr"

############

#Unpacking path

md $drivepath\$parentfolder

.\msixmgr.exe -Unpack -packagePath $msixpath -destination "$drivepath\$parentfolder" -applyacls

CD $drivepath\$parentfolder

$pkname = ls | Select-Object Name | ForEach-Object {$_.Name}

$pkname

$volumeguid = mountvol $drivepath /L

$volumeguid = $volumeguid.Trim()
$volumeguid

########

Start-Sleep -s 30

#unmount

Dismount-VHD -Path $vhdpath -Verbose

Start-Sleep -s 40

$vhdSrc=$vhdpath

$packageName = $pkname

$parentFolder = $parentfolder

$parentFolder = "\" + $parentFolder + "\"

$msixJunction = "C:\temp\AppAttach\"

#endregion

#region mountvhd

try

{

    Mount-Diskimage -ImagePath $vhdSrc -NoDriveLetter -Access ReadOnly                 

    Write-Host ("Mounting of " + $vhdSrc + " was completed!") -BackgroundColor Green
    Start-Sleep -s 10

}

catch

{

    Write-Host ("Mounting of " + $vhdSrc + " has failed!") -BackgroundColor Red

}

#endregion

#region makelink

$msixDest = $volumeguid

if (!(Test-Path $msixJunction))

{

    md $msixJunction

}

$msixJunction = $msixJunction + $packageName

 Start-Sleep -s 10

cmd.exe /c mklink /j $msixJunction $msixDest

#endregion

Start-Sleep -s 30

#region stage

[Windows.Management.Deployment.PackageManager,Windows.Management.Deployment,ContentType=WindowsRuntime] | Out-Null

Add-Type -AssemblyName System.Runtime.WindowsRuntime

$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where { $_.ToString() -eq 'System.Threading.Tasks.Task`1[TResult] AsTask[TResult,TProgress](Windows.Foundation.IAsyncOperationWithProgress`2[TResult,TProgress])'})[0]

$asTaskAsyncOperation = $asTask.MakeGenericMethod([Windows.Management.Deployment.DeploymentResult], [Windows.Management.Deployment.DeploymentProgress])

$packageManager = [Windows.Management.Deployment.PackageManager]::new()

$path = $msixJunction + $parentFolder + $packageName # needed if we do the pbisigned.vhd

$path = ([System.Uri]$path).AbsoluteUri

$asyncOperation = $packageManager.StagePackageAsync($path, $null, "StageInPlace")

$task = $asTaskAsyncOperation.Invoke($null, @($asyncOperation))

$task

#endregion
Start-Sleep -s 30

#MSIX app attach registration

#region variables

$packageName = $pkname

$path = "C:\Program Files\WindowsApps\" + $packageName + "\AppxManifest.xml"

#endregion

#region register

Add-AppxPackage -Path $path -DisableDevelopmentMode -Register
Start-Sleep -s 30
#endregion

}
else {
Write-Host "The Required modules are not installed...Installing Now" -ForegroundColor Red
Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All -NoRestart
Write-Host "Installed modules for Creating VHD...Please restart the system and Run the script" -ForegroundColor Yellow
Start-Sleep -s 30
}

########
