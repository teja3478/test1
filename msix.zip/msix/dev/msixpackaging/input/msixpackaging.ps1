﻿param(
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msi,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msixpackaging_TargetDirectory,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$guid,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msixpackaging_outputdirectory,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$fldrDate2
    #[parameter(Mandatory=$true)]
    #[ValidateNotNullOrEmpty()]
    #[string]$msixpackaging_signtool,
    #[parameter(Mandatory=$true)]
    #[ValidateNotNullOrEmpty()]
    #[string]$msixpackaging_pfxcert
    #[parameter(Mandatory=$true)]
    #[ValidateNotNullOrEmpty()]
    #[string]$msixpackaging_controlleroutputDirectory
    
)

#[System.IO.FileInfo]$Path = "C:\project\tortoisesvn.msi"
function getmsiproperty([string]$Property,[System.IO.FileInfo]$Path){
Process {
    try {
        # Read property from MSI database
        $WindowsInstaller = New-Object -ComObject WindowsInstaller.Installer
        $MSIDatabase = $WindowsInstaller.GetType().InvokeMember("OpenDatabase", "InvokeMethod", $null, $WindowsInstaller, @($Path.FullName, 0))
        $Query = "SELECT Value FROM Property WHERE Property = '$($Property)'"
        $View = $MSIDatabase.GetType().InvokeMember("OpenView", "InvokeMethod", $null, $MSIDatabase, ($Query))
        $View.GetType().InvokeMember("Execute", "InvokeMethod", $null, $View, $null)
        $Record = $View.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $View, $null)
        $Value = $Record.GetType().InvokeMember("StringData", "GetProperty", $null, $Record, 1)
 
        # Commit database and close view
        $MSIDatabase.GetType().InvokeMember("Commit", "InvokeMethod", $null, $MSIDatabase, $null)
        $View.GetType().InvokeMember("Close", "InvokeMethod", $null, $View, $null)           
        $MSIDatabase = $null
        $View = $null
 
        # Return the value
        return $Value
    } 
    catch {
        Write-Warning -Message $_.Exception.Message ; break
    }
}
End {
    # Run garbage collection and release ComObject
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($WindowsInstaller) | Out-Null
    [System.GC]::Collect()
}
}
#variableupdate
#$msi = "\\\\VDIaaSLabSrv101\\msifiles\\tortoisesvn.msi"
$msiname = $msi.split('\\')
$filename = $msiname[-1]
$msiname = $msiname[-1].split('.')

#$msixpackaging_TargetDirectory = "C:\\MSIXPACKAGED\\input\\"
$sampletemplate = $msixpackaging_TargetDirectory + "sampletemplate.xml"
$msipath = $msixpackaging_TargetDirectory + $filename

#$guid="9c6fcccd9bfe436fa1e9d1bbcf419b62"
#$msixpackaging_outputdirectory = "\\\\VDIAASLABSRV101\\logs"
#$fldrDate2 = "20020284"
#$msixpackaging_signtool = "C:\\Program Files (x86)\\Windows Kits\\10\\bin\\10.0.18362.0\\x64\\signtool.exe"
#$msixpackaging_pfxcert = "C:\\Users\\ansible\\Desktop\\testsign1.pfx"
#$msixpackaging_controlleroutputDirectory= "C:\\MSIXPACKAGED\\output\\"
$msixpackaging_controlleroutputDirectory = $msixpackaging_TargetDirectory.replace("input","output")
$msipath = [System.IO.FileInfo]$msipath
#$ProductVersion=getmsiproperty "ProductVersion" $msipath
$ProductVersion="1.2.3.0"
$ProductName = getmsiproperty "ProductName" $msipath
$Manufacturer = getmsiproperty "Manufacturer" $msipath

$ProductVersion=[string]$ProductVersion
$ProductName = [string]$ProductName
$Manufacturer = [string]$Manufacturer



#templateupdate
$xml = [xml](Get-Content $sampletemplate)
$Path1 = [string]$msipath
$msipath = $Path1.split('\\')
$msiname = $msipath[-1].split('.')
#$xml.MsixPackagingToolTemplate.SaveLocation.PackagePath = $msixpackaging_controlleroutputDirectory+"\\"+$msiname[0]+"\\"+$msiname[0]+".msix"
$xml.MsixPackagingToolTemplate.SaveLocation.PackagePath = $msixpackaging_controlleroutputDirectory+"\\"+"package.msix"
$xml.MsixPackagingToolTemplate.SaveLocation.TemplatePath= $msixpackaging_controlleroutputDirectory+"\\"+$msiname[0]+"\\"+$msiname[0]+".xml"
$xml.MsixPackagingToolTemplate.Installer.Path = $Path1
$xml.MsixPackagingToolTemplate.Installer.InstallLocation = "C:\Program Files\"+$msiname[0]
$xml.MsixPackagingToolTemplate.PackageInformation.PackageName = $msiname[0]
$xml.MsixPackagingToolTemplate.PackageInformation.PackageDisplayName=$ProductName.Trim()
$xml.MsixPackagingToolTemplate.PackageInformation.PublisherDisplayName=$Manufacturer.Trim()
$versionlength = $ProductVersion.split('.')
if($versionlength.Length -gt 3){
$xml.MsixPackagingToolTemplate.PackageInformation.Version=$ProductVersion.Trim()}
else{
$xml.MsixPackagingToolTemplate.PackageInformation.Version=$ProductVersion.Trim()+'.0'
}



$xml.MsixPackagingToolTemplate.PackageInformation.PackageDescription=$ProductName.Trim()
#$outputxml = "C:\"+$msiname[0]+'.xml'
$outputxml = 'C:\package.xml'
$xml.save($outputxml)

write-host($outputxml)
$outputmsix = $msixpackaging_controlleroutputDirectory+$msiname[0]+"\"+$msiname[0]+".msix"
write-host($outputmsix)
$outputmsix1 = $msixpackaging_controlleroutputDirectory+$msiname[0]
write-host($outputmsix1)
$outputmsix2 = $msiname[0]+".msix"
write-host($outputmsix2)
Write-Host($msixpackaging_outputdirectory+"\"+$fldrDate2+"\"+$guid+"\"+"msixpackaging\"+$msiname[0]+".msix")
Write-Host($msixpackaging_controlleroutputDirectory+"package.msix")
#splitting GUID with _
$newguid = "$guid"
$newguid1 = $newguid.split("_")
#Write-Output $newguid1
Write-Host($msixpackaging_outputdirectory+"\"+$fldrDate2+"\"+$newguid1[0]+"\"+"msixpackaging\"+$msiname[0]+".msix")


#packaging msix
#$machinePassword = ConvertTo-SecureString "wipro@123" -AsPlainText -Force
#echo "MsixPackagingTool.exe create-package --template ""$outputxml""  -v" >> C:\"$guid".bat

#msix packagin
#$time = (get-date).AddMinutes(2)
#$timeplus5mins = $time.ToString("HH:mm")
#$timeplus5mins
#$trigger = New-ScheduledTaskTrigger -Once -At $timeplus5mins
#Set-ScheduledTask -TaskName test -TaskPath "\msix" -Trigger $trigger


#sleep 180
#signing
#$outputmsix = "C:\output\"+$msiname[0]+".msix"
#$command = '"C:\Program Files (x86)\Windows Kits\10\bin\10.0.18362.0\x64\signtool.exe" sign /fd SHA256 /a /f "C:\testsign1.pfx" /p wipro@123 '+$outputmsix 
#cmd.exe /c $command

