param(
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$outputmsix
)

$command = 'signtool sign /fd SHA256 /a /f "C:\testsign1.pfx" /p wipro@123 '+$outputmsix 
cmd.exe /c $command
