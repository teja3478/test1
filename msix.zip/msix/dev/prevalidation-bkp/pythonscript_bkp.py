#! /usr/bin/python3
import csv
import re
import json
import sys


stri=""
filename1='output/'+str(sys.argv[1])+'.csv'
filename2='output/'+str(sys.argv[1])+'.txt'
#Complus=str(sys.argv[1].split('.')[0]}+'_complus'
Complus='complus'
Font='font'
#Font=str(sys.argv[1].split('.')[0])+'_font'
with open(filename1,'r') as csv_file:
    #csvreader=csv.reader(csv_file)
    #fields=next(csvreader)
    #for row in csvreader:
     #   print(row)
#    print(csvreader['Table'])
    stri=csv_file.read()
    if stri.find('Complus') != -1:
        print("found")
        json_file=open('config/output/var.json','r+')
        json_obj=json.load(json_file)
        print(json_obj)
        json_obj[Complus]="True"
        print(json_obj)
        json_file.seek(0)
        json.dump(json_obj,json_file)
        json_file.truncate()

    if stri.find('Font') != -1:
        print('found')
        json_file=open('config/output/var.json','r+')
        json_obj=json.load(json_file)
        print(json_obj)
        json_obj[Font]="True"
        print(json_obj)
        json_file.seek(0)
        json.dump(json_obj,json_file)
        json_file.truncate()

rr=[]
string=""
filename3='config/output/'+str(sys.argv[1])+'dll.txt'
file=open(filename3,'w')
file.close()
font_list=['.otf\n','.ttf\n','.fnt\n']

with open(filename2,'r') as file_re:
    #stri=file_re.read()
    for item in file_re:
        if item.endswith('.dll\n'):
            with open(filename3,'a') as file:
                file.write(item.split('\t')[-1].rstrip()+'\n')

        for f in font_list:
            if item.endswith(f):
                json_file=open('config/output/var.json','r+')
                json_obj=json.load(json_file)
                json_obj['fontfile']="True"
                json_file.seek(0)
                json.dump(json_obj,json_file)
                json_file.truncate()



