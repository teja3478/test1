﻿Set-Content C:\PreInstallationpackages\preinstall_ps.txt 'pre installationcompleted'
