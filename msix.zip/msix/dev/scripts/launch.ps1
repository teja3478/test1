Param(

    [Parameter(Mandatory=$True)]
    $package
)
     
     
     $familyname = (Get-AppxPackage $package).PackageFamilyName
     $apps=(Get-AppxPackage $package | Get-AppPackageManifest).Package.Applications.Application

     foreach($app in $apps)
     {
     $appid=$app.Id
     $path=$app.Executable.Replace("VFS\ProgramFilesX64","C:\\Program Files").Replace("VFS\ProgramFilesX86","C:\\Program Files (x86)")
     $executable="/c ""$path"""
     Invoke-CommandInDesktopPackage "cmd" -Args $executable -PackageFamilyName $familyname -AppId $appid -PreventBreakaway
     Start-Sleep -Seconds 10
     }

