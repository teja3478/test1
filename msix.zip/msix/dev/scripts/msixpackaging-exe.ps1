param(
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msi,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msixpackaging_TargetDirectory,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$guid,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$msixpackaging_outputdirectory,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$fldrDate2
    
)

$msiname = $msi.split('\\')
$filename = $msiname[-1]
$msiname = $msiname[-1].split('.')

$msixpackaging_TargetDirectory = "C:\\MSIXPACKAGED\\input\\"
$sampletemplate = $msixpackaging_TargetDirectory + "sampletemplate-exe.xml"
$msipath = $msixpackaging_TargetDirectory + $filename

$msixpackaging_controlleroutputDirectory = $msixpackaging_TargetDirectory.replace("input","output")

#for exe under product version last number should be zero 0
#$ProductVersion1=(get-item -Path $msipath).versioninfo.FileVersion
#$j = $ProductVersion1.Substring(0, $ProductVersion1.LastIndexOf('.'))
#$k = $j.Substring(0, $j.LastIndexOf('.'))
$ProductVersion = "1.2.3.0" 
$ProductName=(get-item -Path $msipath).versioninfo.productname
$Manufacturer =(get-item -Path $msipath).versioninfo.companyname

$ProductVersion=[string]$ProductVersion
$ProductName = [string]$ProductName
$Manufacturer = [string]$Manufacturer

#templateupdate
$xml = [xml](Get-Content $sampletemplate)
$Path1 = [string]$msipath
$msipath = $Path1.split('\\')
$msiname = $msipath[-1].split('.')
#$xml.MsixPackagingToolTemplate.SaveLocation.PackagePath = $msixpackaging_controlleroutputDirectory+"\\"+$msiname[0]+"\\"+$msiname[0]+".msix"
$xml.MsixPackagingToolTemplate.SaveLocation.PackagePath = $msixpackaging_controlleroutputDirectory+"\\"+"package.msix"
$xml.MsixPackagingToolTemplate.SaveLocation.TemplatePath= $msixpackaging_controlleroutputDirectory+"\\"+$msiname[0]+"\\"+$msiname[0]+".xml"
$xml.MsixPackagingToolTemplate.Installer.Path = $Path1
#$xml.MsixPackagingToolTemplate.Installer.Arguments = $Arguments
$xml.MsixPackagingToolTemplate.Installer.Arguments = "/SILENT /S /qn /ALLUsers"
$xml.MsixPackagingToolTemplate.Installer.InstallLocation = "C:\Program Files\"+$msiname[0]
$xml.MsixPackagingToolTemplate.PackageInformation.PackageName = $msiname[0]
$xml.MsixPackagingToolTemplate.PackageInformation.PackageDisplayName=$ProductName.Trim()
$xml.MsixPackagingToolTemplate.PackageInformation.PublisherDisplayName=$Manufacturer.Trim()
$versionlength = $ProductVersion.split('.')
if($versionlength.Length -gt 3){
$xml.MsixPackagingToolTemplate.PackageInformation.Version=$ProductVersion.Trim()}
else{
$xml.MsixPackagingToolTemplate.PackageInformation.Version=$ProductVersion.Trim()+'.0'
}


$xml.MsixPackagingToolTemplate.PackageInformation.PackageDescription=$ProductName.Trim()
#$outputxml = "C:\"+$msiname[0]+'.xml'
$outputxml = 'C:\package.xml'
$xml.save($outputxml)

write-host($outputxml)
$outputmsix = $msixpackaging_controlleroutputDirectory+$msiname[0]+"\"+$msiname[0]+".msix"
write-host($outputmsix)
$outputmsix1 = $msixpackaging_controlleroutputDirectory+$msiname[0]
write-host($outputmsix1)
$outputmsix2 = $msiname[0]+".msix"
write-host($outputmsix2)
Write-Host($msixpackaging_outputdirectory+"\"+$fldrDate2+"\"+$guid+"\"+"msixpackaging\"+$msiname[0]+".msix")
Write-Host($msixpackaging_controlleroutputDirectory+"package.msix")
#splitting GUID with _
$newguid = "$guid"
$newguid1 = $newguid.split("_")
#Write-Output $newguid1
Write-Host($msixpackaging_outputdirectory+"\"+$fldrDate2+"\"+$newguid1[0]+"\"+"msixpackaging\"+$msiname[0]+".msix")


