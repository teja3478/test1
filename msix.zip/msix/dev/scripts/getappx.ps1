Param(

    [Parameter(Mandatory=$True)]
    $package
)

Get-AppxPackage   "*$package*"

Get-AppxPackage   "*$package*"  >> C:\$package.txt
