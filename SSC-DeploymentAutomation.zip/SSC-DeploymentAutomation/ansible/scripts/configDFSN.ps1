  Param(
    
    [Parameter(Mandatory=$true)] $primaryserver

  )
 
  
   #$cluster_nodes= "ankitaDFS1,ankitaDFS2"
   $Sharepathroots= ""
   $domainname="virtuadesklab.ad"
   $namespacename="testdfs"
   #$primaryserver="ankitaDFS1"

   $folders = ("C:\dfsroots\$namespacename") 
   mkdir -path $folders
   $folders | ForEach-Object {$sharename = (Get-Item $_).name; New-SMBShare -Name $shareName -Path $_ -FullAccess Everyone}
        
   New-DfsnRoot -Path \\$domainname\$namespacename -TargetPath \\$primaryserver\$namespacename -Type DomainV2

   New-DfsnFolder -Path \\$domainname\$namespacename\SCS\GDC-DC3\Volume1 -TargetPath \\sofscluster32\volume1
   New-DfsnFolder -Path \\$domainname\$namespacename\SCS\GDC-DC3\Volume2 -TargetPath \\sofscluster32\volume2
