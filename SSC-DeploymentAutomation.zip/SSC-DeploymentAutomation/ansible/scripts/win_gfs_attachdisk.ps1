#!powershell
# Copyright: (c) 2017, Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Module Ansible.ModuleUtils.Backup

$ErrorActionPreference = 'Stop'

$params = Parse-Args -arguments $args -supports_check_mode $true
$check_mode = Get-AnsibleParam -obj $params -name "_ansible_check_mode" -type "bool" -default $false
$diff_mode = Get-AnsibleParam -obj $params -name "_ansible_diff" -type "bool" -default $false


$DataCoreServer = Get-AnsibleParam -obj $params -name "DataCoreServer" -type "str"
$DisksCount = Get-AnsibleParam -obj $params -name "DisksCount" -type "str"

$result = @{
    changed = $false
}

if ($diff_mode) {
    $result.diff = @{}
}

try {
       
    # Start the iscsi service
    Set-Service -Name msiscsi -StartupType Automatic
    Start-Service msiscsi

   # 1. Register Datacore IP in iSCSI Initiator


   New-IscsiTargetPortal -TargetPortalAddress $DataCoreServer #-InitiatorPortalAddress $FileServerSecIP 
   $targets = Get-IscsiTarget
   foreach ($target in $targets){
       
       Connect-IscsiTarget -IsMultipathEnabled $true -NodeAddress $target.NodeAddress -IsPersistent $true
   }
   Start-Sleep -Seconds 10

  

   # 2. Initialize Disk
   # 3. Create Partition & Assign Drive Letter
   # 4. Format Disk & Assign Label
    $volumeCount = $DisksCount
    Write-Host $volumeCount
    $VDName
    for($i = 01; $i -le $volumeCount; $i++ ) {
           if($i -le 9){
                $VDName = 'Volume0'+$i
                $j = '0'+$i
            }
           elseif($i -ge 10){
                $VDName = 'Volume'+$i
                $j = $i
            }
            
           Initialize-Disk $j
           if($j -eq '01'){
              New-Partition -DriveLetter Q -UseMaximumSize -DiskNumber $j
              Format-Volume -FileSystem NTFS -NewFileSystemLabel Quorum -DriveLetter Q -Force -Confirm:$false
           }
           else{

               #New-Partition -UseMaximumSize -DiskNumber $j
               New-Partition -AssignDriveLetter -UseMaximumSize -DiskNumber $j
               $DriveLetter = (Get-Partition -DiskNumber $j -PartitionNumber 2).DriveLetter
               Format-Volume -FileSystem NTFS -NewFileSystemLabel $VDName -DriveLetter $DriveLetter -Force -Confirm:$false
           }

         }
}
catch {
   return "ERROR"
}


$result.changed = $true

Exit-Json -obj $result

