#!powershell

# Copyright: (c) 2015, Jon Hawkesworth (@jhawkesworth) <figs@unity.demon.co.uk>
# Copyright: (c) 2017, Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Module Ansible.ModuleUtils.Backup

$ErrorActionPreference = 'Stop'

$params = Parse-Args -arguments $args -supports_check_mode $true
$check_mode = Get-AnsibleParam -obj $params -name "_ansible_check_mode" -type "bool" -default $false
$diff_mode = Get-AnsibleParam -obj $params -name "_ansible_diff" -type "bool" -default $false

$primaryserver = Get-AnsibleParam -obj $params -name "primaryserver" -type "str"
$namespacename = Get-AnsibleParam -obj $params -name "namespacename" -type "str"
$domainname = Get-AnsibleParam -obj $params -name "domainname" -type "str"

$Sharepathroots= ""



$result = @{
    changed = $false
}

if ($diff_mode) {
    $result.diff = @{}
}


   #$cluster_nodes= "ankitaDFS1,ankitaDFS2"


   $folders = ("C:\dfsroots\$namespacename") 
   mkdir -path $folders
   $folders | ForEach-Object {$sharename = (Get-Item $_).name; New-SMBShare -Name $shareName -Path $_ -FullAccess Everyone}
        
   New-DfsnRoot -Path \\$domainname\$namespacename -TargetPath \\$primaryserver\$namespacename -Type DomainV2

   New-DfsnFolder -Path \\$domainname\$namespacename\SCS\GDC-DC3\Volume1 -TargetPath \\sofscluster32\volume1
   New-DfsnFolder -Path \\$domainname\$namespacename\SCS\GDC-DC3\Volume2 -TargetPath \\sofscluster32\volume2

$result.changed = $true


Exit-Json -obj $result
