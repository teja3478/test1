#!powershell

# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Module Ansible.ModuleUtils.Backup

$ErrorActionPreference = 'Stop'

$params = Parse-Args -arguments $args -supports_check_mode $true
$check_mode = Get-AnsibleParam -obj $params -name "_ansible_check_mode" -type "bool" -default $false
$diff_mode = Get-AnsibleParam -obj $params -name "_ansible_diff" -type "bool" -default $false

$listnodes = Get-AnsibleParam -obj $params -name "cluster_nodes" -type "str"
$cluster_name = Get-AnsibleParam -obj $params -name "cluster_name" -type "str"
$cluster_ip = Get-AnsibleParam -obj $params -name "cluster_ip" -type "str"
$FScluster_name = Get-AnsibleParam -obj $params -name "FScluster_name" -type "str"
$FScluster_ip = Get-AnsibleParam -obj $params -name "FScluster_ip" -type "str"
$ADSGName = Get-AnsibleParam -obj $params -name "ADSGName" -type "str"
$DisksCount = Get-AnsibleParam -obj $params -name "DisksCount" -type "str"
$PrimaryNode = Get-AnsibleParam -obj $params -name "PrimaryNode" -type "str"
$SecondaryNode = Get-AnsibleParam -obj $params -name "SecondaryNode" -type "str"


$result = @{
    changed = $false
}

if ($diff_mode) {
    $result.diff = @{}
}

Import-Module FailoverClusters
#if (! (Get-Cluster -Name $cluster_name -ErrorAction SilentlyContinue))
#{
    try {
    
        # 1. Create Cluster
        $cluster_ip = [String]$cluster_ip
        #New-Cluster -Name $cluster_name -Node $listNodes -NoStorage -StaticAddress $cluster_ip -Verbose
        #Start-Sleep -Seconds 200 
#
       Get-ClusterAvailableDisk | Add-ClusterDisk

        Suspend-ClusterNode -Name $SecondaryNode -TargetNode $PrimaryNode -Drain
                                                                            
        Resume-ClusterNode -Name $SecondaryNode -Failback NoFailback
        Start-Sleep -Seconds 30 
        
        
        
        $FScluster_ip = [String]$FScluster_ip
        $avaiablestorage = (Get-ClusterGroup -Name "Available Storage" | Get-ClusterResource).Name
        Add-ClusterFileServerRole -StaticAddress $FScluster_ip -Name $FScluster_name -Storage $avaiablestorage
        Start-Sleep -Seconds 120
        
            $volumeslist = (Get-Volume -FileSystemLabel "Volume*").FileSystemLabel
            $i = $volumeslist.Count
            for($j=0; $j -le $i-1;$j++){
                $volumelists = $volumeslist[$j]
                #Write-Log -Message "volume name $volumelists" -logfile $logFile
                $driveLetter = (Get-Volume -FileSystemLabel $volumeslist).DriveLetter
                $paths = $driveLetter+':\Shares\'+$volumeslist
                mkdir -path $paths
                Start-Sleep -Seconds 30
                New-SmbShare -Name $volumeslist -Path $paths -ContinuouslyAvailable $true -FullAccess $ADSGName

        }

            
    }
    catch {
        return "ERROR"
    }
#}

$result.changed = $true

Exit-Json -obj $result


