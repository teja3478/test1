#!powershell

# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Module Ansible.ModuleUtils.Backup

$ErrorActionPreference = 'Stop'

$params = Parse-Args -arguments $args -supports_check_mode $true
$check_mode = Get-AnsibleParam -obj $params -name "_ansible_check_mode" -type "bool" -default $false
$diff_mode = Get-AnsibleParam -obj $params -name "_ansible_diff" -type "bool" -default $false

$cluster_nodes = Get-AnsibleParam -obj $params -name "cluster_nodes" -type "str"
$cluster_name = Get-AnsibleParam -obj $params -name "cluster_name" -type "str"
$cluster_ip = Get-AnsibleParam -obj $params -name "cluster_ip" -type "str"
$FScluster_name = Get-AnsibleParam -obj $params -name "FScluster_name" -type "str"
$FScluster_ip = Get-AnsibleParam -obj $params -name "FScluster_ip" -type "str"
$ADSGName = Get-AnsibleParam -obj $params -name "ADSGName" -type "str"
$DisksCount = Get-AnsibleParam -obj $params -name "DisksCount" -type "str"
$PrimaryNode = Get-AnsibleParam -obj $params -name "PrimaryNode" -type "str"
$SecondaryNode = Get-AnsibleParam -obj $params -name "SecondaryNode" -type "str"


$result = @{
    changed = $false
}

if ($diff_mode) {
    $result.diff = @{}
}

Function CreateCluster  {
    Import-Module FailoverClusters
    
   # if (! (Get-Cluster -Name $cluster_name -ErrorAction SilentlyContinue))
   # {
        try {  
            $cluster_ip=[string]$cluster_ip          
            #New-Cluster -Name $cluster_name -Node $listNodes -StaticAddress $cluster_ip
            #Start-Sleep -Seconds 100
            $cluster_name = $cluster_name+".virtuadesklab.ad"
             Add-ClusterScaleOutFileServerRole -Name $FScluster_name -Cluster $cluster_name
             Start-Sleep -Seconds 120
            $volumeCount = $DisksCount
             Write-Host $volumeCount
             $VDName
           
             

                Get-ClusterAvailableDisk -All | Add-ClusterDisk                                                                                                                                                                                                    

                Move-ClusterGroup -Name $FScluster_name -Node $PrimaryNode

                Suspend-ClusterNode -Name $SecondaryNode -TargetNode $PrimaryNode -Drain
                Start-Sleep -Seconds 30                                                                     
                Resume-ClusterNode -Name $SecondaryNode -Failback NoFailback
             
             
                $volumeCount = $DisksCount
                 for($i = 01; $i -le $volumeCount; $i++ ) {
                    
                    $ClusterDisk = "Cluster Disk "+$i
                    $VDName = 'Volume'+$i
                    Suspend-ClusterResource -Name $ClusterDisk
                    Start-Sleep -Seconds 20
                    New-Partition -DiskNumber $i -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel $VDName
                    
                    Start-Sleep -Seconds 60
                    Resume-ClusterResource -Name $ClusterDisk
                    Start-Sleep -Seconds 20
                    Add-ClusterSharedVolume -Name $ClusterDisk
                    Start-Sleep -Seconds 20  
                      
                }
                
                $volumeCount = $DisksCount
                for($i = 01; $i -le $volumeCount; $i++ ) {
                   $volume = 'volume'+$i
                    $path =  "C:\ClusterStorage\$volume\Shares\$volume"
                    mkdir $path  
                    Start-Sleep -Seconds 20  
                      
                                                                                             
                    New-SmbShare -Name $volume -Path $path -ContinuouslyAvailable $true -FullAccess $ADSGName
                }
                

                
        }
        catch {
            return "ERROR"
        }
   # }
   # else
   # {
   # }
    
}


$listNodes = $cluster_nodes.Split(",")
$ClusterNodesCount = $listNodes.Count

try {
    $status = CreateCluster
    if ($status -eq "ERROR") {
        return "ERROR"
    }
}
catch {
    return "ERROR"
}


$result.changed = $true

Exit-Json -obj $result

