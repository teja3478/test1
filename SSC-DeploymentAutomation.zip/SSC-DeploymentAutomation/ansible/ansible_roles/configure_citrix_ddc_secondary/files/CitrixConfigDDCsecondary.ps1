Param(
    
[Parameter(Mandatory=$True)]
    $DDC01
)


#  Add-PSSnapin Citrix.*

  Add-XDController -AdminAddress localhost -SiteControllerAddress $DDC01
  #Set-BrokerSite -TrustRequestsSentToTheXmlServicePort $true


