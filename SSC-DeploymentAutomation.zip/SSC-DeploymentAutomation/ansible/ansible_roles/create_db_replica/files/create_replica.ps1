Param(
    [Parameter(Mandatory=$True)]
    $Domain


)

    $Domain="{{Domain}}"
    $computername=$env:computername
    $serverObject = (Get-Item "SQLSERVER:\SQL\$computername\DEFAULT")
    $serverVersion = $serverObject.Version
    $saReplicaList = [System.Collections.ArrayList]@()
    $saReplica = New-SqlAvailabilityReplica -Name $computername -EndpointURL "TCP://$computername`.$Domain`:5022" -AvailabilityMode "SynchronousCommit" -FailoverMode Automatic -ConnectionModeInSecondaryRole AllowNoConnections -Version $serverVersion.Major -AsTemplate
    $saReplicaList.Add($saReplica);

