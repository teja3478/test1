
Param(
    [Parameter(Mandatory=$True)] 
    $sqlNodes,

    [Parameter(Mandatory=$True)]
    $cluster_quorum_share,

    [Parameter(Mandatory=$True)]
    $availGroupName,

    [Parameter(Mandatory=$True)]
    $testDB
)


Function ConverToFull {
    Param (
        [Parameter(Mandatory=$True)]
        $SimpleDBName
    )

    $DesiredRecoveryModel = 'FULL' # Valid options are SIMPLE, FULL and BULK_LOGGED (upper case)

    $DBProps = Invoke-Sqlcmd -Query "SELECT * FROM sys.databases WHERE name = '$SimpleDBName'"
    Invoke-Sqlcmd -Query "USE master; ALTER DATABASE ""$($DBProps.name)"" SET RECOVERY $DesiredRecoveryModel"
    $DBProps2 = Invoke-Sqlcmd -Query "SELECT * FROM sys.databases WHERE name = '$SimpleDBName'"
}

Function NewDBtoAG {
    $serverOne = $listSQLNodes[0]

    $DatabaseBackupFile = "$cluster_quorum_share\$testDB.bak"  
    $LogBackupFile = "$cluster_quorum_share\$testDB.log"  

    try {
        Import-Module SQLPS -DisableNameChecking

        ConverToFull -SimpleDBName $testDB

        # Backup DB to Quorum Share
        $status = Backup-SqlDatabase -Database $testDB -BackupFile $DatabaseBackupFile -ServerInstance "$serverOne"  
        $status = Backup-SqlDatabase -Database $testDB -BackupFile $LogBackupFile -ServerInstance "$serverOne" -BackupAction 'Log'  
        Start-Sleep -Seconds 10
        # Restore DB on Secondary SQL Nodes
        foreach($sqlNode in $listSQLNodes) {
            if ($sqlNode -ne $serverOne) {
                Restore-SQLDatabase -Database $testDB -ServerInstance "$sqlNode" -BackupFile $DatabaseBackupFile -NoRecovery -ReplaceDatabase -Verbose #-RelocateFile @($RelocateData, $RelocateLog)
                Restore-SQLDatabase -Database $testDB -ServerInstance "$sqlNode" -BackupFile $LogBackupFile -NoRecovery -RestoreAction Log -ReplaceDatabase -Verbose 
                Start-Sleep -Seconds 10
            }
        }

        # Add Test DB on Secondary Servers to AG
        foreach($sqlNode in $listSQLNodes) {
            Add-SqlAvailabilityDatabase -Path "SQLSERVER:\SQL\$sqlNode\DEFAULT\AvailabilityGroups\$availGroupName" -Database $testDB -Verbose
        }
    }
    catch {
    }
}


$listSQLNodes = $sqlNodes.Split(",")
$SQLNodesCount = $listSQLNodes.Count

try {
    $status = NewDBtoAG
    if ($status -eq "ERROR") {
        return "ERROR"
    }
}
catch {
    return "ERROR"
}

