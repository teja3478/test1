
Param(
    [Parameter(Mandatory=$True)]
    $SFExistingServer,

    [Parameter(Mandatory=$True)]
    $BaseUrl

)

# PREREQUISITES -----------------
# Import StoreFront PowerShell modules
  import-module "C:\Program Files\Citrix\Receiver StoreFront\Scripts\ImportModules.ps1"
  Start-Sleep 10
  Add-PSSnapin Citrix.*

# Set Stop on error
	$ErrorActionPreference = "Stop"
# Disable open file security warnings
	$env:SEE_MASK_NOZONECHECKS = 1
# -------------------------------

# VARIABLES ---------------------
# User defined variables
$StartDTM = (Get-Date)

# Pre-defined variables
# Locations
	$RemoteConfigFolder = "_CONFIG"
	$RemoteConfigPath = "\\$SFExistingServer\c$"
	$RemoteRedirectPath = "\inetpub\wwwroot\"
	$LocalConfigFolder = "_CONFIG"
	$LocalConfigPath = "C:"
	$LocalRedirectPath = "C:\inetpub\wwwroot\"
# Files and scripts
	$RedirectFile = "SFRedirect.html"
	$RemoteRedirectPage = $RemoteConfigPath + $RemoteRedirectPath + $Redirectfile
	$RemotePasscodeScript = "$RemoteConfigPath\$RemoteConfigFolder\SFPasscodeScript.ps1"
	$LocalPasscodeScript = "$LocalConfigPath\$LocalConfigFolder\SFPasscodeScript.ps1"
# -------------------------------

# SCRIPT ------------------------
# Create PowerShell Session object
	$PSSession = New-PSSession -ComputerName $SFExistingServer
# Check if folders and/or files already exist
	if((Test-Path $RemoteConfigPath\$RemoteConfigFolder) -eq 0 ) {
		mkdir $RemoteConfigPath\$RemoteConfigFolder
	}
	if((Test-Path $RemotePasscodeScript) -ne 0) {
		Remove-Item $RemotePasscodeScript
		}
	if((Test-Path $RemoteConfigPath\$RemoteConfigFolder\Passcode.txt) -ne 0) {
		Remove-Item $RemoteConfigPath\$RemoteConfigFolder\Passcode.txt
	}
# Create script on existing StoreFront server
	Add-Content $RemotePasscodeScript ". ""C:\Program Files\Citrix\Receiver StoreFront\Scripts\ImportModules.ps1"""
	Add-Content $RemotePasscodeScript "Start-DSClusterJoinService"
	Add-Content $RemotePasscodeScript "`$Passcode = (Get-DSClusterJoinServicePasscode).Response.Passcode"
	Add-Content $RemotePasscodeScript "`$Passcode > $LocalConfigPath\$LocalConfigFolder\Passcode.txt"
# Run script on existing StoreFront server
        $dateTime = Get-Date -f "HH:mm"
        $val = $dateTime.Split(":")
        $min = [int]$val[1]+2 
        $time = $val[0]+":"+$min

	schtasks /Create /F /TN SFPasscodeScript /S $SFExistingServer /RU "SYSTEM" /TR "powershell.exe -File $LocalPasscodeScript" /SC once /ST $time
	schtasks /Run /TN SFPasscodeScript /S $SFExistingServer
	While ((schtasks /Query /TN SFPasscodeScript /S $SFExistingServer /fo List)[5] -notlike "*Ready") {
	}
	Start-Sleep -Seconds 30
	$SFPasscode = Get-Content -Path "$RemoteConfigPath\$RemoteConfigFolder\Passcode.txt"
	schtasks /Delete /TN SFPasscodeScript /S $SFExistingServer /F
	Remove-Item $RemoteConfigPath\$RemoteConfigFolder\Passcode.txt
	Remove-Item $RemotePasscodeScript
# Join new server to StoreFront group and wait a while for completion
	Start-DSClusterJoinService
	Start-DSClusterMemberJoin -authorizerHostName $SFExistingServer -authorizerPasscode $SFPasscode
	Start-Sleep -s 300
	Invoke-Command -Session $PSSession -Scriptblock {
		. "C:\Program Files\Citrix\Receiver StoreFront\Scripts\ImportModules.ps1"
		Stop-DSClusterJoinService
	}
	Start-Sleep -seconds 30
	Stop-DSClusterJoinService
# -------------------------------

# Propagate changes from existing StoreFront server
	$PSSession = New-PSSession -computerName $SFExistingServer
	Invoke-Command -Session $PSSession -Scriptblock {
		Add-PSSnapin Citrix*
		Start-DSConfigurationReplicationClusterUpdate -confirm:$FALSE
        }
Start-Sleep -s 300

