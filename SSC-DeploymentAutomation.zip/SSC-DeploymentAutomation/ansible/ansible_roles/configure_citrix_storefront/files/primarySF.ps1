
# PREREQUISITES -----------------
Param(
    [Parameter(Mandatory=$True)]
    $BaseUrl,

    [Parameter(Mandatory=$True)]
    $XDDCValues,

    [Parameter(Mandatory=$True)]
    $DDC01IP,

    [Parameter(Mandatory=$True)]
    $DDC02IP,

    [Parameter(Mandatory=$True)]
    $StoreFriendlyName,

    [Parameter(Mandatory=$True)]
    $XDFarmName,

    [Parameter(Mandatory=$True)]
    $ExternalURL,
	
    [Parameter(Mandatory=$True)]
    $DomainName


)


$XDDCs = $XDDCValues.Split(",")
# Import required PowerShell modules
import-module "C:\Program Files\Citrix\Receiver StoreFront\Scripts\ImportModules.ps1"
Start-Sleep 10

#Add-PSSnapin Citrix.*

	$SiteID = "1"
	$StoreFriendlyNameWithoutSpaces = $StoreFriendlyName -replace '\s',''
	$StoreVirtualPath = "/Citrix/" + $StoreFriendlyName -replace '\s',''
	$StoreVirtualPathWeb = $StoreVirtualPath + "Web"
	$StoreURL = $BaseUrl + "/Citrix/" + $StoreFriendlyNameWithoutSpaces
	$FarmType = "XenDesktop"
	$TransportType = "HTTPS"
	$ServicePort = "443"
	$SslRelayPort = "443"
# Create initial store (will be deleted after creation of the definitive store)
if ($XDDCs.Count -gt 1) {
	set-dsinitialconfiguration -hostbaseurl $BaseUrl `
		-farmname $XDFarmName `
		-port 80 `
		-transporttype HTTP `
		-sslrelayport 443 `
		-servers @("tempddc.domain.lan") `
		-loadbalance $false `
		-farmtype "XenDesktop" `
		-storevirtualpath /Citrix/TEMP `
		-webreceivervirtualpath /Citrix/TEMPWeb
} else {
	set-dsinitialconfiguration -hostbaseurl $BaseUrl `
		-farmname $XDFarmName `
		-port 443 `
		-transporttype HTTPS `
		-sslrelayport 443 `
		-servers @("tempddc.domain.lan") `
		-loadbalance $false `
		-farmtype "XenDesktop" `
		-storevirtualpath /Citrix/TEMP `
		-webreceivervirtualpath /Citrix/TEMPWeb
}
# -------------------------------

if ($XDDCs.Count -gt 0) {
	$AuthSummary = Get-DSAuthenticationServicesSummary -SiteID $SiteID
	Install-DSStoreServiceAndConfigure -SiteID $SiteID `
		-FriendlyName $StoreFriendlyName `
		-VirtualPath $StoreVirtualPath `
		-AuthSummary $AuthSummary `
		-FarmName $XDFarmName `
		-FarmType $FarmType `
		-Servers $XDDCs `
		-TransportType $TransportType `
		-ServicePort $ServicePort `
		-SslRelayPort $SslRelayPort

	Install-DSWebReceiver -FriendlyName $StoreFriendlyName `
		-SiteID "1" `
		-StoreURL $StoreURL `
		-useHttps $false `
		-VirtualPath $StoreVirtualPathWeb

}



# Remove initial store ----------
	Remove-DSStore2 -SiteID "1" -VirtualPath "/Citrix/TEMP"

$SecureTicketAuthorityUrls1 = "http://$DDC01IP" 
$SecureTicketAuthorityUrls2 = "http://$DDC02IP" 
Add-DSGlobalV10Gateway -Address $ExternalURL -Id 1 -Logon Domain -Name nsgateway -CallbackUrl $ExternalURL -IsDefault $True -RequestTicketTwoSTA $True -SecureTicketAuthorityUrls $SecureTicketAuthorityUrls1,$SecureTicketAuthorityUrls2 -SessionReliability $True

Set-DSStoreRemoteAccess -RemoteAccessType StoresOnly -SiteId 1 -VirtualPath /Citrix/$StoreFriendlyName

$gateway = Get-DSGlobalGateway -GatewayId 1

Set-DSStoreGateways -SiteId 1 -VirtualPath "/Citrix/$StoreFriendlyName" -Gateways $gateway

$AuthService = Get-STFAuthenticationService -SiteID 1 -VirtualPath "/Citrix/Authentication"
Enable-STFAuthenticationServiceProtocol -AuthenticationService $AuthService -Name "CitrixAGBasic"

$AuthService = Get-STFAuthenticationService -SiteID 1 -VirtualPath "/Citrix/Authentication"
#Set-STFExplicitCommonOptions -AuthenticationService $AuthService -Domains "ctxdemo.com" -DefaultDomain "ctxdemo.com"
Set-STFExplicitCommonOptions -AuthenticationService $AuthService -Domains $DomainName -DefaultDomain $DomainName

$AuthService = Get-STFAuthenticationService -SiteID 1 -VirtualPath "/Citrix/Authentication"
Enable-STFAuthenticationServiceProtocol -AuthenticationService $AuthService -Name "IntegratedWindows"
# -------------------------------
