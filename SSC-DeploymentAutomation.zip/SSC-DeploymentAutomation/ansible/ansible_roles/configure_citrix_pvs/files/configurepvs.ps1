Param(
    [Parameter(Mandatory=$True)] $DatabaseServer,
    [Parameter(Mandatory=$True)] $DatabaseName,
    [Parameter(Mandatory=$True)] $FarmName,
    [Parameter(Mandatory=$True)] $SiteName,
    [Parameter(Mandatory=$True)] $DefaultCollectionName,
    [Parameter(Mandatory=$True)] $DefaultStoreName,
    [Parameter(Mandatory=$True)] $LicenseServer,
    [Parameter(Mandatory=$True)] $UserName,
    [Parameter(Mandatory=$True)] $Password,
    [Parameter(Mandatory=$True)] $FarmAdminGroupName,
    [Parameter(Mandatory=$True)] $SiteAdminGroupName,
    [Parameter(Mandatory=$True)] $CollectionAdminGroupName,
    [Parameter(Mandatory=$True)] $MaxPasswordAge
    #[Parameter(Mandatory=$True)] $UNCStoreName,
   # [Parameter(Mandatory=$True)] $UNCStoreDescription,
    #[Parameter(Mandatory=$True)] $UNCStorePath
)

# define Error handling
# note: do not change these values
$global:ErrorActionPreference = "Stop"
if($verbose){ $global:VerbosePreference = "Continue" }

#==========================================================================

# FUNCTION DS_CreateRegistryKey
#==========================================================================
Function DS_CreateRegistryKey {
    [CmdletBinding()]
        Param(
                [Parameter(Mandatory=$true, Position = 0)][String]$RegKeyPath
        )

    if ( Test-Path $RegKeyPath ) {
    } else {
        try {
            New-Item -Path $RegkeyPath -Force | Out-Null
            }
            catch{
            Exit 1
            }
    }
}
#==========================================================================

# FUNCTION DS_SetRegistryValue
#==========================================================================
Function DS_SetRegistryValue {
    [CmdletBinding()]
        Param(
                [Parameter(Mandatory=$true, Position = 0)][String]$RegKeyPath,
                [Parameter(Mandatory=$true, Position = 1)][String]$RegValueName,
                [Parameter(Mandatory=$false, Position = 2)][String[]]$RegValue = "",
                [Parameter(Mandatory=$true, Position = 3)][String]$Type
        )

    # Create the registry key in case it does not exist
    if ( !( Test-Path $RegKeyPath ) ) {
        DS_CreateRegistryKey $RegKeyPath
    }

    # Create the registry value
    try {
        if ( ( "String", "ExpandString", "DWord", "QWord" ) -contains $Type ) {
                    New-ItemProperty -Path $RegKeyPath -Name $RegValueName -Value $RegValue[0] -PropertyType $Type -Force | Out-Null
            } else {
                    New-ItemProperty -Path $RegKeyPath -Name $RegValueName -Value $RegValue -PropertyType $Type -Force | Out-Null
            }
    } catch {
        Exit 1
    }
}
#==========================================================================

# FUNCTION DS_CreateDirectory
#==========================================================================
Function DS_CreateDirectory {
    [CmdletBinding()]
        Param(
                [Parameter(Mandatory=$true, Position = 0)][String]$Directory
        )

    if ( Test-Path $Directory ) {
    } else {
        try {
            New-Item -ItemType Directory -Path $Directory -force | Out-Null
        } catch {
            Exit 1
        }
    }
}
#==========================================================================

# FUNCTION DS_DeleteDirectory
# Description: delete the entire directory
#==========================================================================
Function DS_DeleteDirectory {
    [CmdletBinding()]
        Param(
                [Parameter(Mandatory=$true, Position = 0)][String]$Directory
        )

    if ( Test-Path $Directory ) {
        try {
            Remove-Item $Directory -force -recurse | Out-Null
        } catch {
            Exit 1
        }
    }
}
#==========================================================================

# FUNCTION DS_DeleteFile
# Description: delete one specific file
#==========================================================================
Function DS_DeleteFile {
    [CmdletBinding()]
        Param(
                [Parameter(Mandatory=$true, Position = 0)][String]$File
        )

    if ( Test-Path $File ) {
        try {
            Remove-Item "$File" | Out-Null
        } catch {
            Exit 1
        }
    }
}
#==========================================================================

# FUNCTION DS_CreateFirewallRule
#==========================================================================
Function DS_CreateFirewallRule {
    [CmdletBinding()]
        Param(
        [Parameter(Mandatory=$true, Position = 0)][String]$Name,
        [Parameter(Mandatory=$true, Position = 1)][AllowEmptyString()][String]$Description,
        [Parameter(Mandatory=$true, Position = 2)][String]$Ports,
        [Parameter(Mandatory=$true, Position = 3)][String]$Protocol,
        [Parameter(Mandatory=$true, Position = 4)][ValidateSet("Inbound","Outbound",IgnoreCase = $True)][String]$Direction,
        [Parameter(Mandatory=$true, Position = 5)][ValidateSet("Allow","Block",IgnoreCase = $True)][String]$Action
    )

    [string]$WindowsVersion = ( Get-WmiObject -class Win32_OperatingSystem ).Version
    if ( ($WindowsVersion -like "*6.1*") -Or ($WindowsVersion -like "*6.0*") ) {
        # Configure the local firewall using the NetSh command if the operating system is Windows Server 2008 (R2)
        if ( $Direction -eq "Inbound" ) { $DirectionNew = "In" }
        if ( $Direction -eq "Outbound" ) { $DirectionNew = "Out" }
        try {
            [string]$Rule = netsh advfirewall firewall show rule name=$Name
            if ( $Rule.Contains("No rules match") ) {
                try {
                    netsh advfirewall firewall add rule name=$Name description=$Description localport=$Ports protocol=$Protocol dir=$DirectionNew action=$Action | Out-Null
                } catch  {
                    Exit 1
                }
            }
        } catch {
            Exit 1
        }
    } else {
        # Configure the local firewall using PowerShell if the operating system is Windows Server 2012 or higher
        if ( (Get-NetFirewallRule -Name $Name -ErrorAction SilentlyContinue) -Or (Get-NetFirewallRule -DisplayName $Name -ErrorAction SilentlyContinue)) {

        } else {
            [array]$Ports = $Ports.split(',')  # Convert the string value $Ports to an array (required by the PowerShell cmdlet 'New-NetFirewallRule')
            try {
                    New-NetFirewallRule -Name $Name -DisplayName $Name -Description $Description -LocalPort $Ports -Protocol $Protocol -Direction $Direction -Action $Action | Out-Null
            } catch  {
                Exit 1
            }
        }
    }
}
#==========================================================================

# Function DS_CreatePVSAuthGroup
# Note: Create a new Provisioning Server authorization group
#==========================================================================
import-Module "C:\Program Files\Citrix\Provisioning Services Console\Citrix.PVS.SnapIn.dll"

Function DS_CreatePVSAuthGroup {
    [CmdletBinding()]
        Param(
                [Parameter(Mandatory=$true, Position = 0)][String]$GroupName
        )

    try {
        Get-PvsAuthGroup -Name $GroupName | Out-Null
    } catch {
        try {
            New-PvsAuthGroup -Name $GroupName | Out-Null
        } catch {
            Exit 1
        }
    }
}
#==========================================================================

# Function DS_GrantPVSAuthGroupAdminRights
# Note: Grant an existing Provisioning Server authorization group farm, site or collection admin rights
#==========================================================================
Function DS_GrantPVSAuthGroupAdminRights {
    [CmdletBinding()]
        Param(
                [Parameter(Mandatory=$true, Position = 0)][String]$GroupName,
                [Parameter(Mandatory=$false)][String]$SiteName,
                [Parameter(Mandatory=$false)][String]$CollectionName
        )

    # Before attempting to grant admin rights, make sure that the authorization group exists
    try {
        Get-PvsAuthGroup -Name $GroupName | Out-Null
    } catch {
        DS_CreatePVSAuthGroup -GroupName $GroupName
    }

    # Grant admin rights to the authorization group
    try {
        if ( ([string]::IsNullOrEmpty($SiteName)) -And ([string]::IsNullOrEmpty($CollectionName)) ) {
            # Grant farm admin rights when both parameters 'SiteName' and 'CollectionName' are empty
            $result = "farm"
            Grant-PvsAuthGroup -authGroupName $GroupName | Out-Null
        } Elseif ( !([string]::IsNullOrEmpty($CollectionName)) ) {
            # Grant collection admin rights when the parameter 'CollectionName' is NOT empty
            $result = "collection"
            Grant-PvsAuthGroup -authGroupName $GroupName -SiteName $SiteName -CollectionName $CollectionName | Out-Null
        } Else {
            # Grant site admin rights in all other cases
            $result = "site"
            Grant-PvsAuthGroup -authGroupName $GroupName -SiteName $SiteName | Out-Null
        }
    } catch {
        [string]$ErrorText = $Error[0]
        If ( $ErrorText.Contains("duplicate")) {
        } else {
            Exit 1
        }
    }
}
#==========================================================================

################
# Main section #
################

# Disable File Security
$env:SEE_MASK_NOZONECHECKS = 1

# Custom variables [edit]
$BaseLogDir = "C:\Logs"                                         # [edit] add the location of your log directory here
$PackageName = "Citrix Provisioning Server (configure)"         # [edit] enter the display name of the software (e.g. 'Arcobat Reader' or 'Microsoft Office')

# Global variables
$ComputerName = $env:ComputerName
$StartDir = $PSScriptRoot # the directory path of the script currently being executed
if (!($Installationtype -eq "Uninstall")) { $Installationtype = "Install" }
$LogDir = (Join-Path $BaseLogDir $PackageName).Replace(" ","_")
$LogFileName = "$($Installationtype)_$($PackageName).log"
$LogFile = Join-path $LogDir $LogFileName

# Create the log directory if it does not exist
if (!(Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType directory | Out-Null }

# Create new log file (overwrite existing one)
New-Item $LogFile -ItemType "file" -force | Out-Null


# -----------------------------------
# CUSTOMIZE THE FOLLOWING VARIABLES TO YOUR REQUIREMENTS
# -----------------------------------
Write-Verbose "Setting Arguments" -Verbose
$StartDTM = (Get-Date)

#$MyConfigFileloc = ("\\guestvm\Citrix\PVS\Settings.xml")
#[xml]$MyConfigFile = (Get-Content $MyConfigFileLoc)

Write-Verbose "Import PowerShell Module" -Verbose
Add-PSSnapin Citrix.*

$ipV4 = Test-Connection -ComputerName (hostname) -Count 1  | Select -ExpandProperty IPV4Address
#$DatabaseServer = $MyConfigFile.Settings.Citrix.Databaseserver
$DatabaseInstance = "" # Leave empty if your SQL server only has one default instance
$DefaultStorePath = "C:\$DefaultStoreName" #$MyConfigFile.Settings.Citrix.DefaultStorePath
$LicenseServerPort = "27000" #$MyConfigFile.Settings.Citrix.LicenseServerPort
$StreamingIP = $ipV4.IPAddressToString #$MyConfigFile.Settings.Citrix.StreamingIP                                                               # If left empty, the script will use the IP address from the first online network adapter
$FirstStreamingPort = "6910" #$MyConfigFile.Settings.Citrix.FirstStreamingPort
$LastStreamingPort = "6968" #$MyConfigFile.Settings.Citrix.LastStreamingPort
$BootIP = $ipV4.IPAddressToString #$MyConfigFile.Settings.Citrix.BootIP                                                                  # If left empty, the script will use the IP address from the first online network adapter
#################################################
# CONFIGURE THE LOCAL FIREWALL                  #
#################################################

# Note 1: The local firewall is not configured during the installation of Provisioning Server
# Note 2: in case you use a Microsoft Group Policy object to configure the firewall, you can delete the following lines of code


# Create the inbound rule for the TCP ports
DS_CreateFirewallRule -Name "Citrix PVS (Inbound,TCP)" -Description "Inbound rules for the TCP protocol for Citrix Provisioning Server ports" -Ports "389,1433,54321-54323" -Protocol "TCP" -Direction "Inbound" -Action "Allow"
# Create the inbound rule for the UDP ports
DS_CreateFirewallRule -Name "Citrix PVS (Inbound,UDP)" -Description "Inbound rules for the UDP protocol for Citrix Provisioning Server ports" -Ports "67,69,2071,6910-6930,6969,4011,6890-6909" -Protocol "UDP" -Direction "Inbound" -Action "Allow"
# Create the outbound rule for the TCP ports
DS_CreateFirewallRule -Name "Citrix PVS (Outbound,TCP)" -Description "Outbound rules for the TCP protocol for Citrix Provisioning Server ports" -Ports "389,1433,54321-54323" -Protocol "TCP" -Direction "Outbound" -Action "Allow"
# Create the outbound rule for the UDP ports
DS_CreateFirewallRule -Name "Citrix PVS (Outbound,UDP)" -Description "Outbound rules for the UDP protocol for Citrix Provisioning Server ports" -Ports "67,69,2071,6910-6930,6969,4011,6890-6909" -Protocol "UDP" -Direction "Outbound" -Action "Allow"
# CREATE OR JOIN THE PROVISIONING SERVER FARM   #
# Get the IPv4 address of the main network card
try {
    $AvailableNICs = gwmi Win32_NetworkAdapter -Filter "NetEnabled='True'"
    switch ($AvailableNICs.Count)
    {
        {$_ -eq 0 } {
            Exit 1
        }
        {$_ -gt 1 } {
            Exit 1
        }
        default {
            ForEach ($Adapter in $AvailableNICs) {
                $IPv4Address = $(gwmi Win32_NetworkAdapterConfiguration -Filter "Index = '$($Adapter.Index)'").IPAddress
            }
        }
    }
} catch {
    Exit 1
}

# Define the variables for the ANS file for CREATING a NEW farm
$Text += "PXEServiceType="                 + "1"                                                                  + "`r`n"
$Text += "FarmConfiguration="              + "1"                                                                  + "`r`n"   # 0 = farm already configures, 1= create farm, 2 = join farm
$Text += "BootstrapFile="                  + "C:\ProgramData\Citrix\Provisioning Services\Tftpboot\ARDBP32.BIN"   + "`r`n"   # Set the boot strap file for the PVS TFTP service. Leave out this parameter if you do not want to use the PVS TFTP service
$Text += "DatabaseServer="                 + $DatabaseServer                                                      + "`r`n"   # The name of the database (SQL) server
if ( !([string]::IsNullOrEmpty($DatabaseInstance)) ) {
    $Text += "DatabaseInstance="           + $DatabaseInstance                                                    + "`r`n"   # The name of the database instance. Leave out this parameter if there is only one (default) instance on your SQL server
}
$Text += "DatabaseNew="                    + $DatabaseName                                                        + "`r`n"   # The name of the database
$Text += "MultiSubnetFailover"             + "1"                                                                  + "`r`n"
$Text += "FarmNew="                        + $FarmName                                                            + "`r`n"   # The name of the Provisioning Server farm
$Text += "SiteNew="                        + $SiteName                                                            + "`r`n"   # The name of the default site
$Text += "CollectionNew="                  + $DefaultCollectionName                                               + "`r`n"   # The name of the default collection
$Text += "Store="                          + $DefaultStoreName                                                    + "`r`n"   # The name of the default store
$Text += "DefaultPath="                    + $DefaultStorePath                                                    + "`r`n"   # The path to the default store (this directory is created below to avoid errors)
$Text += "PasswordManagementInterval="     + $MaxPasswordAge                                                      + "`r`n"   # Automate computer password updates (number of days between password updates). Leave out this parameter if you do not want PVS to manage the password updates
$Text += "LicenseServer="                  + $LicenseServer                                                       + "`r`n"   # The name of the Citrix license server
$Text += "LicenseServerPort="              + $LicenseServerPort                                                   + "`r`n"   # The port of the Citrix license server used for the initial connection (27000 by default)
if ( [string]::IsNullOrEmpty($StreamingIP) ) {
    $Text += "LS1="                        + "$($IPv4Address),0.0.0.0,0.0.0.0,$FirstStreamingPort"                + "`r`n"   # The IPv4 address of the local server to be added to the stream servers boot list
} else {
    $Text += "LS1="                        + "$($StreamingIP),0.0.0.0,0.0.0.0,$FirstStreamingPort"                + "`r`n"   # The IPv4 address of the local server to be added to the stream servers boot list
}
if ( [string]::IsNullOrEmpty($BootIP) ) {
    $Text += "StreamNetworkAdapterIP="     + $IPv4Address                                                         + "`r`n"   # Set the network adapter IP for the stream servers (comma delimited IP address list). The first card is used if you leave out this parameter
} else {
    $Text += "StreamNetworkAdapterIP="     + $BootIP                                                              + "`r`n"   # Set the network adapter IP for the stream servers (comma delimited IP address list). The first card is used if you leave out this parameter
}
$Text += "UserName="                       + $UserName                                                            + "`r`n"   # The name of a user with SQL sysadmin rights
$Text += "UserPass="                       + $Password                                                            + "`r`n"   # The password of the user with SQL sysadmin rights. Either use UserPass (plain text) or UserName2 (encrypted) for the password.

# Create the Config Wizard ANS file for CREATING a NEW farm
$ConfWizardANSFileCreateFarm = "$env:Temp\ConfigWizardCreateFarm.ans"
try {
    Set-Content $ConfWizardANSFileCreateFarm -value ($Text) -Encoding Unicode
 } catch {
    Exit 1
 }

# Reset/empty the variable $Text
Clear-Variable Text

# Define the variables for the ANS file for JOINING an EXISTING farm
$Text += "PXEServiceType="                 + "1"                                                                  + "`r`n"
$Text += "FarmConfiguration="              + "2"                                                                  + "`r`n"   # 0 = farm already configures, 1= create farm, 2 = join farm
$Text += "DatabaseServer="                 + $DatabaseServer                                                      + "`r`n"   # The name of the database (SQL) server
$Text += "BootstrapFile="                  + "C:\ProgramData\Citrix\Provisioning Services\Tftpboot\ARDBP32.BIN"   + "`r`n"
if ( !([string]::IsNullOrEmpty($DatabaseInstance)) ) {
    $Text += "DatabaseInstance="           + $DatabaseInstance                                                    + "`r`n"   # The name of the database instance. Leave out this parameter if there is only one (default) instance on your SQL server
}
$Text += "FarmExisting="                   + $FarmName                                                            + "`r`n"   # The name of the Provisioning Server farm
$Text += "ExistingSite="                   + $SiteName                                                            + "`r`n"   # The name of the default site
$Text += "ExistingStore="                  + $DefaultStoreName                                                    + "`r`n"   # The name of the default store
if ( [string]::IsNullOrEmpty($StreamingIP) ) {
    $Text += "LS1="                        + "$($IPv4Address),0.0.0.0,0.0.0.0,$FirstStreamingPort"                + "`r`n"   # The IPv4 address of the local server to be added to the stream servers boot list
} else {
    $Text += "LS1="                        + "$($StreamingIP),0.0.0.0,0.0.0.0,$FirstStreamingPort"                + "`r`n"   # The IPv4 address of the local server to be added to the stream servers boot list
}
if ( [string]::IsNullOrEmpty($BootIP) ) {
    $Text += "StreamNetworkAdapterIP="     + $IPv4Address                                                         + "`r`n"   # Set the network adapter IP for the stream servers (comma delimited IP address list). The first card is used if you leave out this parameter
} else {
    $Text += "StreamNetworkAdapterIP="     + $BootIP                                                              + "`r`n"   # Set the network adapter IP for the stream servers (comma delimited IP address list). The first card is used if you leave out this parameter
}
$Text += "PasswordManagementInterval="     + $MaxPasswordAge                                                      + "`r`n"   # Automate computer password updates (number of days between password updates). Leave out this parameter if you do not want PVS to manage the password updates
$Text += "UserName="                       + $UserName                                                            + "`r`n"   # The name of a user with SQL sysadmin rights
$Text += "UserPass="                       + $Password                                                            + "`r`n"   # The password of the user with SQL sysadmin rights. Either use UserPass (plain text) or UserName2 (encrypted) for the password.


# Create the Config Wizard ANS file for JOINING an EXISTING farm
$ConfWizardANSFileJoinFarm = "$env:Temp\ConfigWizardJoinFarm.ans"
try {
    Set-Content $ConfWizardANSFileJoinFarm -value ($Text) -Encoding Unicode
 } catch {
    Exit 1
 }


# Before executing the ConfigWizard.exe, create the directory for the default PVS store (the config wizard ends in an error if the path does not exist)
DS_CreateDirectory -Directory $DefaultStorePath
$ConfigWizardLogFile = "$LogDir\ConfigWizard.log"
DS_DeleteFile -File $ConfigWizardLogFile
# Execute the ConfigWizard and either join or create the Provisioning Server farm
$ConfigWizardEXE = "$env:ProgramFiles\Citrix\Provisioning Services\ConfigWizard.exe"
if ( Test-Path $ConfigWizardEXE ) {
    # Create the farm
    $params = "/a:$ConfWizardANSFileCreateFarm /o:$ConfigWizardLogFile"
    start-process $ConfigWizardEXE $params -WindowStyle Hidden -Wait  # There is no need for a try / catch statement since the ConfigWizard always exists with code 0

    # The ConfigWizard only provides the exit code 0. We have to read the log file to check the result.
    [string]$GetText = Get-Content $ConfigWizardLogFile
    switch -wildcard ($GetText)
    {
        "*Invalid Database Name*" {

            # Delete the ConfigWizard log file (if exist)
            $ConfigWizardLogFile = "$LogDir\ConfigWizard.log"
            DS_DeleteFile -File $ConfigWizardLogFile

            # Join the server to the farm
            $params = "/a:$ConfWizardANSFileJoinFarm /o:$ConfigWizardLogFile"
            start-process $ConfigWizardEXE $params -WindowStyle Hidden -Wait  # There is no need for a try / catch statement since the ConfigWizard always exists with code 0

            # The ConfigWizard only provides the exit code 0. We have to read the log file to check the result.
            [string]$GetText = Get-Content $ConfigWizardLogFile
            if ( $GetText.Contains("Configuration complete") ) {
            } else {
                Exit 1
            }
        }
        "*Configuration complete*" {
        }
        "*Fatal error*" {
        }
    }
}


# Delete the ConfigWizard configuration file (since it contains the password of the Active Directory service account in plain text)
DS_DeleteFile -File $ConfWizardANSFileCreateFarm
DS_DeleteFile -File $ConfWizardANSFileJoinFarm

# Load the Citrix snap-ins
# ========================
try {
    asnp citrix*
} catch {
    Exit 1
}

# Create three new authorization groups
# =====================================
DS_CreatePVSAuthGroup -GroupName $FarmAdminGroupName         # Farm admin group
DS_CreatePVSAuthGroup -GroupName $SiteAdminGroupName         # Site admin group
DS_CreatePVSAuthGroup -GroupName $CollectionAdminGroupName   # Collection admin group

# Grant the authorization groups the appropriate admin rights
# ===========================================================
DS_GrantPVSAuthGroupAdminRights -GroupName $FarmAdminGroupName                                                                      # Grant farm admin rights
DS_GrantPVSAuthGroupAdminRights -GroupName $SiteAdminGroupName -SiteName $SiteName                                                  # Grant site admin rights
DS_GrantPVSAuthGroupAdminRights -GroupName $CollectionAdminGroupName -SiteName $SiteName -CollectionName $DefaultCollectionName     # Grant collection admin rights

# Configure the Provisioning Server farm
try {
    Set-PvsFarm -AuditingEnabled -OfflineDatabaseSupportEnabled -LicenseServer $LicenseServer -LicenseServerPort $LicenseServerPort
} catch {
    Exit 1
}

# Enable the Customer Experience Improvements Program (CEIP)
# ======================================================
try {
    Set-PvsCeipData -enabled 1
} catch {
    Exit 1
}

# Enable verbose mode in the bootstrap configuration
# ==================================================
try {
    Set-PvsServerBootstrap -Name "ARDBP32.bin" -ServerName $env:ComputerName -VerboseMode
} catch {
    #Exit 1
}
# Configure the local host
# ========================
$NumberOfCores = (gwmi win32_ComputerSystem).numberoflogicalprocessors   # this is the total number of cores including hyperthreading
if ( $NumberOfCores -lt 8 ) { $NumberOfCores = 8 }                       # set the threads per port to the default value of 8 in case the number of logical cores is less than 8
try {
    Set-PvsServer -ServerName $env:ComputerName -FirstPort $FirstStreamingPort -LastPort $LastStreamingPort -ThreadsPerPort $NumberOfCores -AdMaxPasswordAge $MaxPasswordAge -AdMaxPasswordAgeEnabled -EventLoggingEnabled
} catch {
    Exit 1
}

DS_SetRegistryValue -RegKeyPath "hklm:\Software\Citrix\ProvisioningServices\StreamProcess" -RegValueName "SkipBootMenu" -RegValue "1" -Type "DWORD"

# ======================
DS_SetRegistryValue -RegKeyPath "hklm:\Software\Citrix\ProvisioningServices\StreamProcess" -RegValueName "SkipRIMSForPrivate" -RegValue "1" -Type "DWORD"

# Enable File Security
Remove-Item env:\SEE_MASK_NOZONECHECKS

