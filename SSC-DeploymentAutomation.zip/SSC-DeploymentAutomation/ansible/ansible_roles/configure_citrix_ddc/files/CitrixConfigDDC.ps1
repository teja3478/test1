

Param(
    [Parameter(Mandatory=$True)]
    $LicenseServer,

    [Parameter(Mandatory=$True)]
    [ValidateSet("true","false")]
    [string]
    $IsPrimary,

    [Parameter(Mandatory=$True)]
    $SiteName,

    [Parameter(Mandatory=$True)]
    $DatabaseServer,

    [Parameter(Mandatory=$True)]
    $DatabaseName_Site,

    [Parameter(Mandatory=$True)]
    $DatabaseName_Logging,

    [Parameter(Mandatory=$True)]
    $DatabaseName_Monitor,

    [Parameter(Mandatory=$True)]
    $DatabaseUser,

    [Parameter(Mandatory=$True)]
    $DatabasePassword,

    [Parameter(Mandatory=$True)]
    $DDC01
)


$ProductVersion = "7.19" 
$LicensingModel = "UserDevice"
$ProductCode = "XDT" 
$ProductEdition = "PLT" 
$Port = "27000" 
$AddressType = "WSL" 

$LicenseServerUri = "https://$LicenseServer`:8083/"

Add-PSSnapin Citrix.*

if ($IsPrimary -eq "true") {
    echo "$($MyInvocation.MyCommand): Server is Primary"
  if (!$SiteName) {
    return "ERROR: SiteName cant be empty."
  }
  if (!$DatabaseServer) {
    return "ERROR: DatabaseServer cant be empty."
  }
  if (!$DatabaseUser) {
    return "ERROR: DatabaseUser cant be empty."
  }
  if (!$DatabasePassword) {
    return "ERROR: DatabasePassword cant be empty."
  }

  $DatabasePassword = $DatabasePassword | ConvertTo-SecureString -asPlainText -Force
  $Database_CredObject = New-Object System.Management.Automation.PSCredential($DatabaseUser,$DatabasePassword)
  
  New-XDDatabase -AdminAddress $env:COMPUTERNAME -SiteName $SiteName -DataStore Site -DatabaseServer $DatabaseServer -DatabaseName $DatabaseName_Site -DatabaseCredentials $Database_CredObject 
  New-XDDatabase -AdminAddress $env:COMPUTERNAME -SiteName $SiteName -DataStore Logging -DatabaseServer $DatabaseServer -DatabaseName $DatabaseName_Logging -DatabaseCredentials $Database_CredObject 
  New-XDDatabase -AdminAddress $env:COMPUTERNAME -SiteName $SiteName -DataStore Monitor -DatabaseServer $DatabaseServer -DatabaseName $DatabaseName_Monitor -DatabaseCredentials $Database_CredObject
  New-XDSite -AdminAddress $env:COMPUTERNAME -SiteName $SiteName -DatabaseServer $DatabaseServer -LoggingDatabaseName $DatabaseName_Logging -MonitorDatabaseName $DatabaseName_Monitor -SiteDatabaseName $DatabaseName_Site
  Set-ConfigSite -AdminAddress $env:COMPUTERNAME -LicenseServerName $LicenseServer -LicenseServerPort $Port -LicensingModel $LicensingModel -ProductCode $ProductCode -ProductEdition $ProductEdition -ProductVersion $ProductVersion
  
  Set-ConfigSite -LicenseServerUri $LicenseServerUri

  $LicenseServer_AdminAddress = Get-LicLocation -AddressType $AddressType -LicenseServerAddress $LicenseServer -LicenseServerPort $Port
  $LicenseServer_CertificateHash = $(Get-LicCertificate  -AdminAddress $LicenseServer_AdminAddress).CertHash
  Set-ConfigSiteMetadata -AdminAddress $env:COMPUTERNAME -Name "CertificateHash" -Value $LicenseServer_CertificateHash
  Set-BrokerSite -TrustRequestsSentToTheXmlServicePort $true

} else {

  Add-XDController -AdminAddress localhost -SiteControllerAddress $DDC01
  Set-BrokerSite -TrustRequestsSentToTheXmlServicePort $true
}


