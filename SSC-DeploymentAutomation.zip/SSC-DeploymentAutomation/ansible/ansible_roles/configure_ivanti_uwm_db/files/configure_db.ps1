        $ServerName = $env:computername
        $ConfigurerUsername = "VIRTUADESKLAB.AD\labtestuser"
        $ConfigurerPassword = 'wipro@123'
        $ServiceUsername = "VIRTUADESKLAB.AD\labtestuser1"
        $ServicePassword = 'wipro@123'
        $DatabaseServer =  "sqlsqlnsr143" #sql listiner.fqdn  fully qualified domain main
        $DatabaseName = "uwmdb12"
        $DatabaseConnection = "NewConnection11"

        $ProductName = Invoke-Command -ComputerName $ServerName -ScriptBlock { Get-ApsInstance | Select-object -ExpandProperty ProductName }
        #Create Configurer credential object
        $SecurePassword = ConvertTo-SecureString -AsPlainText $ConfigurerPassword -Force
        $ConfigurerCrendential = New-Object System.Management.Automation.PSCredential($ConfigurerUsername, $SecurePassword)
        #Create Service credential object
        $SecurePassword = ConvertTo-SecureString -AsPlainText $ServicePassword -Force
        $ServiceCredential = New-Object System.Management.Automation.PSCredential($ServiceUsername, $SecurePassword)
        # install/fix all prerequisites
        #
        #        Get-ApsPrerequisite | Install-ApsPrerequisite
        #Create Database
        Import-Module AppSenseInstances
        Import-ApsInstanceModule -ProductName $ProductName -IsDefault
        Get-ApsPrerequisite | Install-ApsPrerequisite
        Get-Command | Where {$_.Name -eq "Initialize-ApsDatabase"}
        Initialize-ApsDatabase -DatabaseServer $DatabaseServer -DatabaseName $DatabaseName -ConfigurerCredential $ConfigurerCrendential -ServiceCredential $ServiceCredential -DatabaseConnection $ServiceCredential
        Initialize-ApsServer -DatabaseConnection $ServiceCredential

        #Use the Repair-ApsVariance cmdlet to attempt to repair variances:

        #Repair-ApsVariance -All
