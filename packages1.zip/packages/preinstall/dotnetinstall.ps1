﻿$programs = Get-WindowsFeature | where-object {$_.Installed -eq $True}
$dotnet3=$true
$dotnet4=$true
foreach ($program in $programs)
{
    if ($program.DisplayName -like "*.NET Framework 3.5*")
     {
        Write-Host(".NET Framework 3.5 is available")
     } 
    else
     {	
    	   $dotnet3=$false	  
     }

    if ($program.DisplayName -like "*.NET Framework 4*")
     {             
             Write-Host(".NET Framework 4 available")
     }
     else
     {
         
	  $dotnet4=$false
         
     }
}

  if($dotnet3 -eq $false)
  {
       Write-Host(" Installing .NET Framework 3.5 Version")
       #"msiexec /i $msiPath /q /norestart" | Set-Content -Encoding Ascii -Force $installerpath
      "$workingdirectory\dotnetfx35.exe /QUIET  /NORESTART"
  }  

  if($dotnet4 -eq $false)
  {
       Write-Host(" Installing .NET Framework 4.5 Version")
       "$workingdirectory\dotnetfx45.exe /QUIET  /NORESTART"
  }                       
       
