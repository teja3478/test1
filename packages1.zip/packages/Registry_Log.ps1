﻿Remove-Item -Path $PSScriptRoot\Result -Recurse
New-Item -ItemType directory -Path $PSScriptRoot\Result

compare-object $(Get-Content $PSScriptRoot\Reg_Before_HKCU.txt) $(Get-content $PSScriptRoot\Reg_After_HKCU.txt) | Out-File -append $PSScriptRoot\Result\REGISTRY_CHANGES.txt
compare-object $(Get-Content $PSScriptRoot\Reg_Before_HKCC.txt) $(Get-content $PSScriptRoot\Reg_After_HKCC.txt) | Out-File -append $PSScriptRoot\Result\REGISTRY_CHANGES.txt
compare-object $(Get-Content $PSScriptRoot\Reg_Before_HKU.txt) $(Get-content $PSScriptRoot\Reg_After_HKU.txt)   | Out-File -append $PSScriptRoot\Result\REGISTRY_CHANGES.txt
compare-object $(Get-Content $PSScriptRoot\Reg_Before_HKCR.txt) $(Get-content $PSScriptRoot\Reg_After_HKCR.txt) | Out-File -append $PSScriptRoot\Result\REGISTRY_CHANGES.txt
compare-object $(Get-Content $PSScriptRoot\Reg_Before_HKLM.txt) $(Get-content $PSScriptRoot\Reg_After_HKLM.txt) | Out-File -append $PSScriptRoot\Result\REGISTRY_CHANGES.txt

(Get-Content $PSScriptRoot\Result\REGISTRY_CHANGES.txt) | Foreach-Object {$_ -replace 'InputObject', 'Key'` -replace 'SideIndicator', 'Action' ` -replace '=>', 'Added' ` -replace '<=', 'Rmved'  } | Set-Content $PSScriptRoot\Result\REGISTRY_CHANGES.txt


compare-object $(Get-Content $PSScriptRoot\FileSystem_Before.txt) $(Get-content $PSScriptRoot\FileSystem_After.txt) | Out-File $PSScriptRoot\Result\FILESYSTEM_CHANGES.txt
(Get-Content $PSScriptRoot\Result\FILESYSTEM_CHANGES.txt) | Foreach-Object {$_ -replace 'InputObject', 'Key'` -replace 'SideIndicator', 'Action' ` -replace '=>', 'Added' ` -replace '<=', 'Rmved'  } | Set-Content $PSScriptRoot\Result\FILESYSTEM_CHANGES.txt
