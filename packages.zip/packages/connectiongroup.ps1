﻿Param(
[string]$ParentApp,
[string]$guid
)
$internal_counter = 0
#$Apps_array = @("Published Primary app variable", "Published Dep app variable", .... ,"nth published dep variable")
$Apps_array=@()
# Ansible removes the space
#$App_array=$Apps_array.split(" ")
$Apps_array+=$ParentApp
Write-Host("Apps_array",$Apps_array)
[string[]]$dep_array=Get-ChildItem -Path 'c:\dependencies' -Filter *.appv -Recurse -File -Name
$Apps_array+=$dep_array
Write-Host("PublishedApps_array",$Apps_array)
$GUID_Details = @()
$appvList=$Apps_array.Split(" ")
Foreach($appvgrp in $appvList) #loop1
{   
    
   	$app = ($appvgrp.split("."))[0]
	write-Host("App is :", $app )
    $Publishedappv = Get-AppvClientPackage -Name $app
	$current_versionid = $Publishedappv.VersionId.Guid
	$current_Packageid = $Publishedappv.PackageId.Guid

#below $pckXMLData & $ApplicationPackage code for xml should be in exact format/tags
$pckXMLData = @"
<appv:Package VersionId="$current_versionid" PackageId="$current_Packageid"/>
"@
	$GUID_Details+=$pckXMLData

}#loop1_end

	#creating two new GUIDs for defining connection group ID in XML
	$newguid1= New-Guid
	$Connectiongrp_ID = $newguid1.Guid
	$newguid2= New-Guid
	$Connectiongrp_VID = $newguid2.Guid
	$DisplayName = $guid
	$XMLPath = "c:\dependencies\"+$DisplayName + "_ConnectionGrp.xml"

$ApplicationPackage =@"
<?xml version="1.0"?>
<appv:AppConnectionGroup xmlns="http://schemas.microsoft.com/appv/2010/virtualapplicationconnectiongroup" xmlns:appv="http://schemas.microsoft.com/appv/2010/virtualapplicationconnectiongroup" AppConnectionGroupId="$Connectiongrp_ID" VersionId="$Connectiongrp_VID" Priority="0" DisplayName="$DisplayName">
<appv:Packages>
$GUID_Details
</appv:Packages>
</appv:AppConnectionGroup>
"@

	$ApplicationPackage | Out-File $XMLPath -Encoding ascii

	## Enabling Connection group
	Add-AppvClientConnectionGroup -Path $XMLPath | enable-AppVClientConnectionGroup